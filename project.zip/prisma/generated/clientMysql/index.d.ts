
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model account
 * 
 */
export type account = $Result.DefaultSelection<Prisma.$accountPayload>
/**
 * Model checkpoint
 * This table contains check constraints and requires additional setup for migrations. Visit https://pris.ly/d/check-constraints for more info.
 */
export type checkpoint = $Result.DefaultSelection<Prisma.$checkpointPayload>
/**
 * Model joiner
 * This table contains check constraints and requires additional setup for migrations. Visit https://pris.ly/d/check-constraints for more info.
 */
export type joiner = $Result.DefaultSelection<Prisma.$joinerPayload>
/**
 * Model trip
 * This table contains check constraints and requires additional setup for migrations. Visit https://pris.ly/d/check-constraints for more info.
 */
export type trip = $Result.DefaultSelection<Prisma.$tripPayload>

/**
 * ##  Prisma Client ʲˢ
 * 
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Accounts
 * const accounts = await prisma.account.findMany()
 * ```
 *
 * 
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   * 
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Accounts
   * const accounts = await prisma.account.findMany()
   * ```
   *
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): void;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb, ExtArgs>

      /**
   * `prisma.account`: Exposes CRUD operations for the **account** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Accounts
    * const accounts = await prisma.account.findMany()
    * ```
    */
  get account(): Prisma.accountDelegate<ExtArgs>;

  /**
   * `prisma.checkpoint`: Exposes CRUD operations for the **checkpoint** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Checkpoints
    * const checkpoints = await prisma.checkpoint.findMany()
    * ```
    */
  get checkpoint(): Prisma.checkpointDelegate<ExtArgs>;

  /**
   * `prisma.joiner`: Exposes CRUD operations for the **joiner** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Joiners
    * const joiners = await prisma.joiner.findMany()
    * ```
    */
  get joiner(): Prisma.joinerDelegate<ExtArgs>;

  /**
   * `prisma.trip`: Exposes CRUD operations for the **trip** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Trips
    * const trips = await prisma.trip.findMany()
    * ```
    */
  get trip(): Prisma.tripDelegate<ExtArgs>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError
  export import NotFoundError = runtime.NotFoundError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql

  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics 
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 5.19.1
   * Query Engine version: 69d742ee20b815d88e17e54db4a2a7a3b30324e3
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion 

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    * 
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    * 
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   * 
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? K : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    account: 'account',
    checkpoint: 'checkpoint',
    joiner: 'joiner',
    trip: 'trip'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    mysql?: Datasource
  }

  interface TypeMapCb extends $Utils.Fn<{extArgs: $Extensions.InternalArgs, clientOptions: PrismaClientOptions }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], this['params']['clientOptions']>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, ClientOptions = {}> = {
    meta: {
      modelProps: "account" | "checkpoint" | "joiner" | "trip"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      account: {
        payload: Prisma.$accountPayload<ExtArgs>
        fields: Prisma.accountFieldRefs
        operations: {
          findUnique: {
            args: Prisma.accountFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.accountFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          findFirst: {
            args: Prisma.accountFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.accountFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          findMany: {
            args: Prisma.accountFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>[]
          }
          create: {
            args: Prisma.accountCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          createMany: {
            args: Prisma.accountCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.accountDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          update: {
            args: Prisma.accountUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          deleteMany: {
            args: Prisma.accountDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.accountUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.accountUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$accountPayload>
          }
          aggregate: {
            args: Prisma.AccountAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAccount>
          }
          groupBy: {
            args: Prisma.accountGroupByArgs<ExtArgs>
            result: $Utils.Optional<AccountGroupByOutputType>[]
          }
          count: {
            args: Prisma.accountCountArgs<ExtArgs>
            result: $Utils.Optional<AccountCountAggregateOutputType> | number
          }
        }
      }
      checkpoint: {
        payload: Prisma.$checkpointPayload<ExtArgs>
        fields: Prisma.checkpointFieldRefs
        operations: {
          findUnique: {
            args: Prisma.checkpointFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.checkpointFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          findFirst: {
            args: Prisma.checkpointFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.checkpointFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          findMany: {
            args: Prisma.checkpointFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>[]
          }
          create: {
            args: Prisma.checkpointCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          createMany: {
            args: Prisma.checkpointCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.checkpointDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          update: {
            args: Prisma.checkpointUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          deleteMany: {
            args: Prisma.checkpointDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.checkpointUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.checkpointUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$checkpointPayload>
          }
          aggregate: {
            args: Prisma.CheckpointAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCheckpoint>
          }
          groupBy: {
            args: Prisma.checkpointGroupByArgs<ExtArgs>
            result: $Utils.Optional<CheckpointGroupByOutputType>[]
          }
          count: {
            args: Prisma.checkpointCountArgs<ExtArgs>
            result: $Utils.Optional<CheckpointCountAggregateOutputType> | number
          }
        }
      }
      joiner: {
        payload: Prisma.$joinerPayload<ExtArgs>
        fields: Prisma.joinerFieldRefs
        operations: {
          findUnique: {
            args: Prisma.joinerFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.joinerFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          findFirst: {
            args: Prisma.joinerFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.joinerFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          findMany: {
            args: Prisma.joinerFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>[]
          }
          create: {
            args: Prisma.joinerCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          createMany: {
            args: Prisma.joinerCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.joinerDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          update: {
            args: Prisma.joinerUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          deleteMany: {
            args: Prisma.joinerDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.joinerUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.joinerUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$joinerPayload>
          }
          aggregate: {
            args: Prisma.JoinerAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateJoiner>
          }
          groupBy: {
            args: Prisma.joinerGroupByArgs<ExtArgs>
            result: $Utils.Optional<JoinerGroupByOutputType>[]
          }
          count: {
            args: Prisma.joinerCountArgs<ExtArgs>
            result: $Utils.Optional<JoinerCountAggregateOutputType> | number
          }
        }
      }
      trip: {
        payload: Prisma.$tripPayload<ExtArgs>
        fields: Prisma.tripFieldRefs
        operations: {
          findUnique: {
            args: Prisma.tripFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.tripFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          findFirst: {
            args: Prisma.tripFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.tripFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          findMany: {
            args: Prisma.tripFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>[]
          }
          create: {
            args: Prisma.tripCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          createMany: {
            args: Prisma.tripCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.tripDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          update: {
            args: Prisma.tripUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          deleteMany: {
            args: Prisma.tripDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.tripUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.tripUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tripPayload>
          }
          aggregate: {
            args: Prisma.TripAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTrip>
          }
          groupBy: {
            args: Prisma.tripGroupByArgs<ExtArgs>
            result: $Utils.Optional<TripGroupByOutputType>[]
          }
          count: {
            args: Prisma.tripCountArgs<ExtArgs>
            result: $Utils.Optional<TripCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
  }


  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type AccountCountOutputType
   */

  export type AccountCountOutputType = {
    joiner: number
    trip: number
  }

  export type AccountCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    joiner?: boolean | AccountCountOutputTypeCountJoinerArgs
    trip?: boolean | AccountCountOutputTypeCountTripArgs
  }

  // Custom InputTypes
  /**
   * AccountCountOutputType without action
   */
  export type AccountCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AccountCountOutputType
     */
    select?: AccountCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * AccountCountOutputType without action
   */
  export type AccountCountOutputTypeCountJoinerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: joinerWhereInput
  }

  /**
   * AccountCountOutputType without action
   */
  export type AccountCountOutputTypeCountTripArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: tripWhereInput
  }


  /**
   * Count Type TripCountOutputType
   */

  export type TripCountOutputType = {
    checkpoint: number
    joiner: number
  }

  export type TripCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    checkpoint?: boolean | TripCountOutputTypeCountCheckpointArgs
    joiner?: boolean | TripCountOutputTypeCountJoinerArgs
  }

  // Custom InputTypes
  /**
   * TripCountOutputType without action
   */
  export type TripCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TripCountOutputType
     */
    select?: TripCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * TripCountOutputType without action
   */
  export type TripCountOutputTypeCountCheckpointArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: checkpointWhereInput
  }

  /**
   * TripCountOutputType without action
   */
  export type TripCountOutputTypeCountJoinerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: joinerWhereInput
  }


  /**
   * Models
   */

  /**
   * Model account
   */

  export type AggregateAccount = {
    _count: AccountCountAggregateOutputType | null
    _min: AccountMinAggregateOutputType | null
    _max: AccountMaxAggregateOutputType | null
  }

  export type AccountMinAggregateOutputType = {
    IDAccount: string | null
    IDGoogle: string | null
    Email: string | null
    Org: boolean | null
    imgURL: string | null
    name: string | null
  }

  export type AccountMaxAggregateOutputType = {
    IDAccount: string | null
    IDGoogle: string | null
    Email: string | null
    Org: boolean | null
    imgURL: string | null
    name: string | null
  }

  export type AccountCountAggregateOutputType = {
    IDAccount: number
    IDGoogle: number
    Email: number
    Org: number
    imgURL: number
    name: number
    _all: number
  }


  export type AccountMinAggregateInputType = {
    IDAccount?: true
    IDGoogle?: true
    Email?: true
    Org?: true
    imgURL?: true
    name?: true
  }

  export type AccountMaxAggregateInputType = {
    IDAccount?: true
    IDGoogle?: true
    Email?: true
    Org?: true
    imgURL?: true
    name?: true
  }

  export type AccountCountAggregateInputType = {
    IDAccount?: true
    IDGoogle?: true
    Email?: true
    Org?: true
    imgURL?: true
    name?: true
    _all?: true
  }

  export type AccountAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which account to aggregate.
     */
    where?: accountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of accounts to fetch.
     */
    orderBy?: accountOrderByWithRelationInput | accountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: accountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned accounts
    **/
    _count?: true | AccountCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AccountMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AccountMaxAggregateInputType
  }

  export type GetAccountAggregateType<T extends AccountAggregateArgs> = {
        [P in keyof T & keyof AggregateAccount]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAccount[P]>
      : GetScalarType<T[P], AggregateAccount[P]>
  }




  export type accountGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: accountWhereInput
    orderBy?: accountOrderByWithAggregationInput | accountOrderByWithAggregationInput[]
    by: AccountScalarFieldEnum[] | AccountScalarFieldEnum
    having?: accountScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AccountCountAggregateInputType | true
    _min?: AccountMinAggregateInputType
    _max?: AccountMaxAggregateInputType
  }

  export type AccountGroupByOutputType = {
    IDAccount: string
    IDGoogle: string | null
    Email: string | null
    Org: boolean | null
    imgURL: string | null
    name: string | null
    _count: AccountCountAggregateOutputType | null
    _min: AccountMinAggregateOutputType | null
    _max: AccountMaxAggregateOutputType | null
  }

  type GetAccountGroupByPayload<T extends accountGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AccountGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AccountGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AccountGroupByOutputType[P]>
            : GetScalarType<T[P], AccountGroupByOutputType[P]>
        }
      >
    >


  export type accountSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    IDAccount?: boolean
    IDGoogle?: boolean
    Email?: boolean
    Org?: boolean
    imgURL?: boolean
    name?: boolean
    joiner?: boolean | account$joinerArgs<ExtArgs>
    trip?: boolean | account$tripArgs<ExtArgs>
    _count?: boolean | AccountCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["account"]>


  export type accountSelectScalar = {
    IDAccount?: boolean
    IDGoogle?: boolean
    Email?: boolean
    Org?: boolean
    imgURL?: boolean
    name?: boolean
  }

  export type accountInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    joiner?: boolean | account$joinerArgs<ExtArgs>
    trip?: boolean | account$tripArgs<ExtArgs>
    _count?: boolean | AccountCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $accountPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "account"
    objects: {
      joiner: Prisma.$joinerPayload<ExtArgs>[]
      trip: Prisma.$tripPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      IDAccount: string
      IDGoogle: string | null
      Email: string | null
      Org: boolean | null
      imgURL: string | null
      name: string | null
    }, ExtArgs["result"]["account"]>
    composites: {}
  }

  type accountGetPayload<S extends boolean | null | undefined | accountDefaultArgs> = $Result.GetResult<Prisma.$accountPayload, S>

  type accountCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<accountFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: AccountCountAggregateInputType | true
    }

  export interface accountDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['account'], meta: { name: 'account' } }
    /**
     * Find zero or one Account that matches the filter.
     * @param {accountFindUniqueArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends accountFindUniqueArgs>(args: SelectSubset<T, accountFindUniqueArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Account that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {accountFindUniqueOrThrowArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends accountFindUniqueOrThrowArgs>(args: SelectSubset<T, accountFindUniqueOrThrowArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Account that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountFindFirstArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends accountFindFirstArgs>(args?: SelectSubset<T, accountFindFirstArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Account that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountFindFirstOrThrowArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends accountFindFirstOrThrowArgs>(args?: SelectSubset<T, accountFindFirstOrThrowArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Accounts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Accounts
     * const accounts = await prisma.account.findMany()
     * 
     * // Get first 10 Accounts
     * const accounts = await prisma.account.findMany({ take: 10 })
     * 
     * // Only select the `IDAccount`
     * const accountWithIDAccountOnly = await prisma.account.findMany({ select: { IDAccount: true } })
     * 
     */
    findMany<T extends accountFindManyArgs>(args?: SelectSubset<T, accountFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Account.
     * @param {accountCreateArgs} args - Arguments to create a Account.
     * @example
     * // Create one Account
     * const Account = await prisma.account.create({
     *   data: {
     *     // ... data to create a Account
     *   }
     * })
     * 
     */
    create<T extends accountCreateArgs>(args: SelectSubset<T, accountCreateArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Accounts.
     * @param {accountCreateManyArgs} args - Arguments to create many Accounts.
     * @example
     * // Create many Accounts
     * const account = await prisma.account.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends accountCreateManyArgs>(args?: SelectSubset<T, accountCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Account.
     * @param {accountDeleteArgs} args - Arguments to delete one Account.
     * @example
     * // Delete one Account
     * const Account = await prisma.account.delete({
     *   where: {
     *     // ... filter to delete one Account
     *   }
     * })
     * 
     */
    delete<T extends accountDeleteArgs>(args: SelectSubset<T, accountDeleteArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Account.
     * @param {accountUpdateArgs} args - Arguments to update one Account.
     * @example
     * // Update one Account
     * const account = await prisma.account.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends accountUpdateArgs>(args: SelectSubset<T, accountUpdateArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Accounts.
     * @param {accountDeleteManyArgs} args - Arguments to filter Accounts to delete.
     * @example
     * // Delete a few Accounts
     * const { count } = await prisma.account.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends accountDeleteManyArgs>(args?: SelectSubset<T, accountDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Accounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Accounts
     * const account = await prisma.account.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends accountUpdateManyArgs>(args: SelectSubset<T, accountUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Account.
     * @param {accountUpsertArgs} args - Arguments to update or create a Account.
     * @example
     * // Update or create a Account
     * const account = await prisma.account.upsert({
     *   create: {
     *     // ... data to create a Account
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Account we want to update
     *   }
     * })
     */
    upsert<T extends accountUpsertArgs>(args: SelectSubset<T, accountUpsertArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Accounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountCountArgs} args - Arguments to filter Accounts to count.
     * @example
     * // Count the number of Accounts
     * const count = await prisma.account.count({
     *   where: {
     *     // ... the filter for the Accounts we want to count
     *   }
     * })
    **/
    count<T extends accountCountArgs>(
      args?: Subset<T, accountCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AccountCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Account.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AccountAggregateArgs>(args: Subset<T, AccountAggregateArgs>): Prisma.PrismaPromise<GetAccountAggregateType<T>>

    /**
     * Group by Account.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {accountGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends accountGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: accountGroupByArgs['orderBy'] }
        : { orderBy?: accountGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, accountGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAccountGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the account model
   */
  readonly fields: accountFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for account.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__accountClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    joiner<T extends account$joinerArgs<ExtArgs> = {}>(args?: Subset<T, account$joinerArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findMany"> | Null>
    trip<T extends account$tripArgs<ExtArgs> = {}>(args?: Subset<T, account$tripArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findMany"> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the account model
   */ 
  interface accountFieldRefs {
    readonly IDAccount: FieldRef<"account", 'String'>
    readonly IDGoogle: FieldRef<"account", 'String'>
    readonly Email: FieldRef<"account", 'String'>
    readonly Org: FieldRef<"account", 'Boolean'>
    readonly imgURL: FieldRef<"account", 'String'>
    readonly name: FieldRef<"account", 'String'>
  }
    

  // Custom InputTypes
  /**
   * account findUnique
   */
  export type accountFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter, which account to fetch.
     */
    where: accountWhereUniqueInput
  }

  /**
   * account findUniqueOrThrow
   */
  export type accountFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter, which account to fetch.
     */
    where: accountWhereUniqueInput
  }

  /**
   * account findFirst
   */
  export type accountFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter, which account to fetch.
     */
    where?: accountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of accounts to fetch.
     */
    orderBy?: accountOrderByWithRelationInput | accountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for accounts.
     */
    cursor?: accountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of accounts.
     */
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * account findFirstOrThrow
   */
  export type accountFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter, which account to fetch.
     */
    where?: accountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of accounts to fetch.
     */
    orderBy?: accountOrderByWithRelationInput | accountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for accounts.
     */
    cursor?: accountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of accounts.
     */
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * account findMany
   */
  export type accountFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter, which accounts to fetch.
     */
    where?: accountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of accounts to fetch.
     */
    orderBy?: accountOrderByWithRelationInput | accountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing accounts.
     */
    cursor?: accountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` accounts.
     */
    skip?: number
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * account create
   */
  export type accountCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * The data needed to create a account.
     */
    data: XOR<accountCreateInput, accountUncheckedCreateInput>
  }

  /**
   * account createMany
   */
  export type accountCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many accounts.
     */
    data: accountCreateManyInput | accountCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * account update
   */
  export type accountUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * The data needed to update a account.
     */
    data: XOR<accountUpdateInput, accountUncheckedUpdateInput>
    /**
     * Choose, which account to update.
     */
    where: accountWhereUniqueInput
  }

  /**
   * account updateMany
   */
  export type accountUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update accounts.
     */
    data: XOR<accountUpdateManyMutationInput, accountUncheckedUpdateManyInput>
    /**
     * Filter which accounts to update
     */
    where?: accountWhereInput
  }

  /**
   * account upsert
   */
  export type accountUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * The filter to search for the account to update in case it exists.
     */
    where: accountWhereUniqueInput
    /**
     * In case the account found by the `where` argument doesn't exist, create a new account with this data.
     */
    create: XOR<accountCreateInput, accountUncheckedCreateInput>
    /**
     * In case the account was found with the provided `where` argument, update it with this data.
     */
    update: XOR<accountUpdateInput, accountUncheckedUpdateInput>
  }

  /**
   * account delete
   */
  export type accountDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    /**
     * Filter which account to delete.
     */
    where: accountWhereUniqueInput
  }

  /**
   * account deleteMany
   */
  export type accountDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which accounts to delete
     */
    where?: accountWhereInput
  }

  /**
   * account.joiner
   */
  export type account$joinerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    where?: joinerWhereInput
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    cursor?: joinerWhereUniqueInput
    take?: number
    skip?: number
    distinct?: JoinerScalarFieldEnum | JoinerScalarFieldEnum[]
  }

  /**
   * account.trip
   */
  export type account$tripArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    where?: tripWhereInput
    orderBy?: tripOrderByWithRelationInput | tripOrderByWithRelationInput[]
    cursor?: tripWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * account without action
   */
  export type accountDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
  }


  /**
   * Model checkpoint
   */

  export type AggregateCheckpoint = {
    _count: CheckpointCountAggregateOutputType | null
    _avg: CheckpointAvgAggregateOutputType | null
    _sum: CheckpointSumAggregateOutputType | null
    _min: CheckpointMinAggregateOutputType | null
    _max: CheckpointMaxAggregateOutputType | null
  }

  export type CheckpointAvgAggregateOutputType = {
    OrderC: number | null
  }

  export type CheckpointSumAggregateOutputType = {
    OrderC: number | null
  }

  export type CheckpointMinAggregateOutputType = {
    IDCheckpoint: string | null
    IDTrip: string | null
    OrderC: number | null
    createTime: Date | null
    time: Date | null
    locationName: string | null
    detail: string | null
    type: string | null
  }

  export type CheckpointMaxAggregateOutputType = {
    IDCheckpoint: string | null
    IDTrip: string | null
    OrderC: number | null
    createTime: Date | null
    time: Date | null
    locationName: string | null
    detail: string | null
    type: string | null
  }

  export type CheckpointCountAggregateOutputType = {
    IDCheckpoint: number
    IDTrip: number
    OrderC: number
    createTime: number
    time: number
    locationName: number
    detail: number
    type: number
    _all: number
  }


  export type CheckpointAvgAggregateInputType = {
    OrderC?: true
  }

  export type CheckpointSumAggregateInputType = {
    OrderC?: true
  }

  export type CheckpointMinAggregateInputType = {
    IDCheckpoint?: true
    IDTrip?: true
    OrderC?: true
    createTime?: true
    time?: true
    locationName?: true
    detail?: true
    type?: true
  }

  export type CheckpointMaxAggregateInputType = {
    IDCheckpoint?: true
    IDTrip?: true
    OrderC?: true
    createTime?: true
    time?: true
    locationName?: true
    detail?: true
    type?: true
  }

  export type CheckpointCountAggregateInputType = {
    IDCheckpoint?: true
    IDTrip?: true
    OrderC?: true
    createTime?: true
    time?: true
    locationName?: true
    detail?: true
    type?: true
    _all?: true
  }

  export type CheckpointAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which checkpoint to aggregate.
     */
    where?: checkpointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of checkpoints to fetch.
     */
    orderBy?: checkpointOrderByWithRelationInput | checkpointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: checkpointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` checkpoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` checkpoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned checkpoints
    **/
    _count?: true | CheckpointCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CheckpointAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CheckpointSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CheckpointMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CheckpointMaxAggregateInputType
  }

  export type GetCheckpointAggregateType<T extends CheckpointAggregateArgs> = {
        [P in keyof T & keyof AggregateCheckpoint]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCheckpoint[P]>
      : GetScalarType<T[P], AggregateCheckpoint[P]>
  }




  export type checkpointGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: checkpointWhereInput
    orderBy?: checkpointOrderByWithAggregationInput | checkpointOrderByWithAggregationInput[]
    by: CheckpointScalarFieldEnum[] | CheckpointScalarFieldEnum
    having?: checkpointScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CheckpointCountAggregateInputType | true
    _avg?: CheckpointAvgAggregateInputType
    _sum?: CheckpointSumAggregateInputType
    _min?: CheckpointMinAggregateInputType
    _max?: CheckpointMaxAggregateInputType
  }

  export type CheckpointGroupByOutputType = {
    IDCheckpoint: string
    IDTrip: string | null
    OrderC: number | null
    createTime: Date | null
    time: Date | null
    locationName: string | null
    detail: string | null
    type: string | null
    _count: CheckpointCountAggregateOutputType | null
    _avg: CheckpointAvgAggregateOutputType | null
    _sum: CheckpointSumAggregateOutputType | null
    _min: CheckpointMinAggregateOutputType | null
    _max: CheckpointMaxAggregateOutputType | null
  }

  type GetCheckpointGroupByPayload<T extends checkpointGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CheckpointGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CheckpointGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CheckpointGroupByOutputType[P]>
            : GetScalarType<T[P], CheckpointGroupByOutputType[P]>
        }
      >
    >


  export type checkpointSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    IDCheckpoint?: boolean
    IDTrip?: boolean
    OrderC?: boolean
    createTime?: boolean
    time?: boolean
    locationName?: boolean
    detail?: boolean
    type?: boolean
    trip?: boolean | checkpoint$tripArgs<ExtArgs>
  }, ExtArgs["result"]["checkpoint"]>


  export type checkpointSelectScalar = {
    IDCheckpoint?: boolean
    IDTrip?: boolean
    OrderC?: boolean
    createTime?: boolean
    time?: boolean
    locationName?: boolean
    detail?: boolean
    type?: boolean
  }

  export type checkpointInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    trip?: boolean | checkpoint$tripArgs<ExtArgs>
  }

  export type $checkpointPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "checkpoint"
    objects: {
      trip: Prisma.$tripPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      IDCheckpoint: string
      IDTrip: string | null
      OrderC: number | null
      createTime: Date | null
      time: Date | null
      locationName: string | null
      detail: string | null
      type: string | null
    }, ExtArgs["result"]["checkpoint"]>
    composites: {}
  }

  type checkpointGetPayload<S extends boolean | null | undefined | checkpointDefaultArgs> = $Result.GetResult<Prisma.$checkpointPayload, S>

  type checkpointCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<checkpointFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: CheckpointCountAggregateInputType | true
    }

  export interface checkpointDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['checkpoint'], meta: { name: 'checkpoint' } }
    /**
     * Find zero or one Checkpoint that matches the filter.
     * @param {checkpointFindUniqueArgs} args - Arguments to find a Checkpoint
     * @example
     * // Get one Checkpoint
     * const checkpoint = await prisma.checkpoint.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends checkpointFindUniqueArgs>(args: SelectSubset<T, checkpointFindUniqueArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Checkpoint that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {checkpointFindUniqueOrThrowArgs} args - Arguments to find a Checkpoint
     * @example
     * // Get one Checkpoint
     * const checkpoint = await prisma.checkpoint.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends checkpointFindUniqueOrThrowArgs>(args: SelectSubset<T, checkpointFindUniqueOrThrowArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Checkpoint that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointFindFirstArgs} args - Arguments to find a Checkpoint
     * @example
     * // Get one Checkpoint
     * const checkpoint = await prisma.checkpoint.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends checkpointFindFirstArgs>(args?: SelectSubset<T, checkpointFindFirstArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Checkpoint that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointFindFirstOrThrowArgs} args - Arguments to find a Checkpoint
     * @example
     * // Get one Checkpoint
     * const checkpoint = await prisma.checkpoint.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends checkpointFindFirstOrThrowArgs>(args?: SelectSubset<T, checkpointFindFirstOrThrowArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Checkpoints that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Checkpoints
     * const checkpoints = await prisma.checkpoint.findMany()
     * 
     * // Get first 10 Checkpoints
     * const checkpoints = await prisma.checkpoint.findMany({ take: 10 })
     * 
     * // Only select the `IDCheckpoint`
     * const checkpointWithIDCheckpointOnly = await prisma.checkpoint.findMany({ select: { IDCheckpoint: true } })
     * 
     */
    findMany<T extends checkpointFindManyArgs>(args?: SelectSubset<T, checkpointFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Checkpoint.
     * @param {checkpointCreateArgs} args - Arguments to create a Checkpoint.
     * @example
     * // Create one Checkpoint
     * const Checkpoint = await prisma.checkpoint.create({
     *   data: {
     *     // ... data to create a Checkpoint
     *   }
     * })
     * 
     */
    create<T extends checkpointCreateArgs>(args: SelectSubset<T, checkpointCreateArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Checkpoints.
     * @param {checkpointCreateManyArgs} args - Arguments to create many Checkpoints.
     * @example
     * // Create many Checkpoints
     * const checkpoint = await prisma.checkpoint.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends checkpointCreateManyArgs>(args?: SelectSubset<T, checkpointCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Checkpoint.
     * @param {checkpointDeleteArgs} args - Arguments to delete one Checkpoint.
     * @example
     * // Delete one Checkpoint
     * const Checkpoint = await prisma.checkpoint.delete({
     *   where: {
     *     // ... filter to delete one Checkpoint
     *   }
     * })
     * 
     */
    delete<T extends checkpointDeleteArgs>(args: SelectSubset<T, checkpointDeleteArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Checkpoint.
     * @param {checkpointUpdateArgs} args - Arguments to update one Checkpoint.
     * @example
     * // Update one Checkpoint
     * const checkpoint = await prisma.checkpoint.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends checkpointUpdateArgs>(args: SelectSubset<T, checkpointUpdateArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Checkpoints.
     * @param {checkpointDeleteManyArgs} args - Arguments to filter Checkpoints to delete.
     * @example
     * // Delete a few Checkpoints
     * const { count } = await prisma.checkpoint.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends checkpointDeleteManyArgs>(args?: SelectSubset<T, checkpointDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Checkpoints.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Checkpoints
     * const checkpoint = await prisma.checkpoint.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends checkpointUpdateManyArgs>(args: SelectSubset<T, checkpointUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Checkpoint.
     * @param {checkpointUpsertArgs} args - Arguments to update or create a Checkpoint.
     * @example
     * // Update or create a Checkpoint
     * const checkpoint = await prisma.checkpoint.upsert({
     *   create: {
     *     // ... data to create a Checkpoint
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Checkpoint we want to update
     *   }
     * })
     */
    upsert<T extends checkpointUpsertArgs>(args: SelectSubset<T, checkpointUpsertArgs<ExtArgs>>): Prisma__checkpointClient<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Checkpoints.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointCountArgs} args - Arguments to filter Checkpoints to count.
     * @example
     * // Count the number of Checkpoints
     * const count = await prisma.checkpoint.count({
     *   where: {
     *     // ... the filter for the Checkpoints we want to count
     *   }
     * })
    **/
    count<T extends checkpointCountArgs>(
      args?: Subset<T, checkpointCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CheckpointCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Checkpoint.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CheckpointAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CheckpointAggregateArgs>(args: Subset<T, CheckpointAggregateArgs>): Prisma.PrismaPromise<GetCheckpointAggregateType<T>>

    /**
     * Group by Checkpoint.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {checkpointGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends checkpointGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: checkpointGroupByArgs['orderBy'] }
        : { orderBy?: checkpointGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, checkpointGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCheckpointGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the checkpoint model
   */
  readonly fields: checkpointFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for checkpoint.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__checkpointClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    trip<T extends checkpoint$tripArgs<ExtArgs> = {}>(args?: Subset<T, checkpoint$tripArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findUniqueOrThrow"> | null, null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the checkpoint model
   */ 
  interface checkpointFieldRefs {
    readonly IDCheckpoint: FieldRef<"checkpoint", 'String'>
    readonly IDTrip: FieldRef<"checkpoint", 'String'>
    readonly OrderC: FieldRef<"checkpoint", 'Int'>
    readonly createTime: FieldRef<"checkpoint", 'DateTime'>
    readonly time: FieldRef<"checkpoint", 'DateTime'>
    readonly locationName: FieldRef<"checkpoint", 'String'>
    readonly detail: FieldRef<"checkpoint", 'String'>
    readonly type: FieldRef<"checkpoint", 'String'>
  }
    

  // Custom InputTypes
  /**
   * checkpoint findUnique
   */
  export type checkpointFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter, which checkpoint to fetch.
     */
    where: checkpointWhereUniqueInput
  }

  /**
   * checkpoint findUniqueOrThrow
   */
  export type checkpointFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter, which checkpoint to fetch.
     */
    where: checkpointWhereUniqueInput
  }

  /**
   * checkpoint findFirst
   */
  export type checkpointFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter, which checkpoint to fetch.
     */
    where?: checkpointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of checkpoints to fetch.
     */
    orderBy?: checkpointOrderByWithRelationInput | checkpointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for checkpoints.
     */
    cursor?: checkpointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` checkpoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` checkpoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of checkpoints.
     */
    distinct?: CheckpointScalarFieldEnum | CheckpointScalarFieldEnum[]
  }

  /**
   * checkpoint findFirstOrThrow
   */
  export type checkpointFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter, which checkpoint to fetch.
     */
    where?: checkpointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of checkpoints to fetch.
     */
    orderBy?: checkpointOrderByWithRelationInput | checkpointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for checkpoints.
     */
    cursor?: checkpointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` checkpoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` checkpoints.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of checkpoints.
     */
    distinct?: CheckpointScalarFieldEnum | CheckpointScalarFieldEnum[]
  }

  /**
   * checkpoint findMany
   */
  export type checkpointFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter, which checkpoints to fetch.
     */
    where?: checkpointWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of checkpoints to fetch.
     */
    orderBy?: checkpointOrderByWithRelationInput | checkpointOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing checkpoints.
     */
    cursor?: checkpointWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` checkpoints from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` checkpoints.
     */
    skip?: number
    distinct?: CheckpointScalarFieldEnum | CheckpointScalarFieldEnum[]
  }

  /**
   * checkpoint create
   */
  export type checkpointCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * The data needed to create a checkpoint.
     */
    data: XOR<checkpointCreateInput, checkpointUncheckedCreateInput>
  }

  /**
   * checkpoint createMany
   */
  export type checkpointCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many checkpoints.
     */
    data: checkpointCreateManyInput | checkpointCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * checkpoint update
   */
  export type checkpointUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * The data needed to update a checkpoint.
     */
    data: XOR<checkpointUpdateInput, checkpointUncheckedUpdateInput>
    /**
     * Choose, which checkpoint to update.
     */
    where: checkpointWhereUniqueInput
  }

  /**
   * checkpoint updateMany
   */
  export type checkpointUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update checkpoints.
     */
    data: XOR<checkpointUpdateManyMutationInput, checkpointUncheckedUpdateManyInput>
    /**
     * Filter which checkpoints to update
     */
    where?: checkpointWhereInput
  }

  /**
   * checkpoint upsert
   */
  export type checkpointUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * The filter to search for the checkpoint to update in case it exists.
     */
    where: checkpointWhereUniqueInput
    /**
     * In case the checkpoint found by the `where` argument doesn't exist, create a new checkpoint with this data.
     */
    create: XOR<checkpointCreateInput, checkpointUncheckedCreateInput>
    /**
     * In case the checkpoint was found with the provided `where` argument, update it with this data.
     */
    update: XOR<checkpointUpdateInput, checkpointUncheckedUpdateInput>
  }

  /**
   * checkpoint delete
   */
  export type checkpointDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    /**
     * Filter which checkpoint to delete.
     */
    where: checkpointWhereUniqueInput
  }

  /**
   * checkpoint deleteMany
   */
  export type checkpointDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which checkpoints to delete
     */
    where?: checkpointWhereInput
  }

  /**
   * checkpoint.trip
   */
  export type checkpoint$tripArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    where?: tripWhereInput
  }

  /**
   * checkpoint without action
   */
  export type checkpointDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
  }


  /**
   * Model joiner
   */

  export type AggregateJoiner = {
    _count: JoinerCountAggregateOutputType | null
    _min: JoinerMinAggregateOutputType | null
    _max: JoinerMaxAggregateOutputType | null
  }

  export type JoinerMinAggregateOutputType = {
    IDTrip: string | null
    IDAccount: string | null
    type: string | null
    status: string | null
  }

  export type JoinerMaxAggregateOutputType = {
    IDTrip: string | null
    IDAccount: string | null
    type: string | null
    status: string | null
  }

  export type JoinerCountAggregateOutputType = {
    IDTrip: number
    IDAccount: number
    type: number
    status: number
    _all: number
  }


  export type JoinerMinAggregateInputType = {
    IDTrip?: true
    IDAccount?: true
    type?: true
    status?: true
  }

  export type JoinerMaxAggregateInputType = {
    IDTrip?: true
    IDAccount?: true
    type?: true
    status?: true
  }

  export type JoinerCountAggregateInputType = {
    IDTrip?: true
    IDAccount?: true
    type?: true
    status?: true
    _all?: true
  }

  export type JoinerAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which joiner to aggregate.
     */
    where?: joinerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of joiners to fetch.
     */
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: joinerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` joiners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` joiners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned joiners
    **/
    _count?: true | JoinerCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: JoinerMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: JoinerMaxAggregateInputType
  }

  export type GetJoinerAggregateType<T extends JoinerAggregateArgs> = {
        [P in keyof T & keyof AggregateJoiner]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateJoiner[P]>
      : GetScalarType<T[P], AggregateJoiner[P]>
  }




  export type joinerGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: joinerWhereInput
    orderBy?: joinerOrderByWithAggregationInput | joinerOrderByWithAggregationInput[]
    by: JoinerScalarFieldEnum[] | JoinerScalarFieldEnum
    having?: joinerScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: JoinerCountAggregateInputType | true
    _min?: JoinerMinAggregateInputType
    _max?: JoinerMaxAggregateInputType
  }

  export type JoinerGroupByOutputType = {
    IDTrip: string
    IDAccount: string
    type: string | null
    status: string | null
    _count: JoinerCountAggregateOutputType | null
    _min: JoinerMinAggregateOutputType | null
    _max: JoinerMaxAggregateOutputType | null
  }

  type GetJoinerGroupByPayload<T extends joinerGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<JoinerGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof JoinerGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], JoinerGroupByOutputType[P]>
            : GetScalarType<T[P], JoinerGroupByOutputType[P]>
        }
      >
    >


  export type joinerSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    IDTrip?: boolean
    IDAccount?: boolean
    type?: boolean
    status?: boolean
    trip?: boolean | tripDefaultArgs<ExtArgs>
    account?: boolean | accountDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["joiner"]>


  export type joinerSelectScalar = {
    IDTrip?: boolean
    IDAccount?: boolean
    type?: boolean
    status?: boolean
  }

  export type joinerInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    trip?: boolean | tripDefaultArgs<ExtArgs>
    account?: boolean | accountDefaultArgs<ExtArgs>
  }

  export type $joinerPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "joiner"
    objects: {
      trip: Prisma.$tripPayload<ExtArgs>
      account: Prisma.$accountPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      IDTrip: string
      IDAccount: string
      type: string | null
      status: string | null
    }, ExtArgs["result"]["joiner"]>
    composites: {}
  }

  type joinerGetPayload<S extends boolean | null | undefined | joinerDefaultArgs> = $Result.GetResult<Prisma.$joinerPayload, S>

  type joinerCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<joinerFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: JoinerCountAggregateInputType | true
    }

  export interface joinerDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['joiner'], meta: { name: 'joiner' } }
    /**
     * Find zero or one Joiner that matches the filter.
     * @param {joinerFindUniqueArgs} args - Arguments to find a Joiner
     * @example
     * // Get one Joiner
     * const joiner = await prisma.joiner.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends joinerFindUniqueArgs>(args: SelectSubset<T, joinerFindUniqueArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Joiner that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {joinerFindUniqueOrThrowArgs} args - Arguments to find a Joiner
     * @example
     * // Get one Joiner
     * const joiner = await prisma.joiner.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends joinerFindUniqueOrThrowArgs>(args: SelectSubset<T, joinerFindUniqueOrThrowArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Joiner that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerFindFirstArgs} args - Arguments to find a Joiner
     * @example
     * // Get one Joiner
     * const joiner = await prisma.joiner.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends joinerFindFirstArgs>(args?: SelectSubset<T, joinerFindFirstArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Joiner that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerFindFirstOrThrowArgs} args - Arguments to find a Joiner
     * @example
     * // Get one Joiner
     * const joiner = await prisma.joiner.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends joinerFindFirstOrThrowArgs>(args?: SelectSubset<T, joinerFindFirstOrThrowArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Joiners that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Joiners
     * const joiners = await prisma.joiner.findMany()
     * 
     * // Get first 10 Joiners
     * const joiners = await prisma.joiner.findMany({ take: 10 })
     * 
     * // Only select the `IDTrip`
     * const joinerWithIDTripOnly = await prisma.joiner.findMany({ select: { IDTrip: true } })
     * 
     */
    findMany<T extends joinerFindManyArgs>(args?: SelectSubset<T, joinerFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Joiner.
     * @param {joinerCreateArgs} args - Arguments to create a Joiner.
     * @example
     * // Create one Joiner
     * const Joiner = await prisma.joiner.create({
     *   data: {
     *     // ... data to create a Joiner
     *   }
     * })
     * 
     */
    create<T extends joinerCreateArgs>(args: SelectSubset<T, joinerCreateArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Joiners.
     * @param {joinerCreateManyArgs} args - Arguments to create many Joiners.
     * @example
     * // Create many Joiners
     * const joiner = await prisma.joiner.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends joinerCreateManyArgs>(args?: SelectSubset<T, joinerCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Joiner.
     * @param {joinerDeleteArgs} args - Arguments to delete one Joiner.
     * @example
     * // Delete one Joiner
     * const Joiner = await prisma.joiner.delete({
     *   where: {
     *     // ... filter to delete one Joiner
     *   }
     * })
     * 
     */
    delete<T extends joinerDeleteArgs>(args: SelectSubset<T, joinerDeleteArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Joiner.
     * @param {joinerUpdateArgs} args - Arguments to update one Joiner.
     * @example
     * // Update one Joiner
     * const joiner = await prisma.joiner.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends joinerUpdateArgs>(args: SelectSubset<T, joinerUpdateArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Joiners.
     * @param {joinerDeleteManyArgs} args - Arguments to filter Joiners to delete.
     * @example
     * // Delete a few Joiners
     * const { count } = await prisma.joiner.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends joinerDeleteManyArgs>(args?: SelectSubset<T, joinerDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Joiners.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Joiners
     * const joiner = await prisma.joiner.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends joinerUpdateManyArgs>(args: SelectSubset<T, joinerUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Joiner.
     * @param {joinerUpsertArgs} args - Arguments to update or create a Joiner.
     * @example
     * // Update or create a Joiner
     * const joiner = await prisma.joiner.upsert({
     *   create: {
     *     // ... data to create a Joiner
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Joiner we want to update
     *   }
     * })
     */
    upsert<T extends joinerUpsertArgs>(args: SelectSubset<T, joinerUpsertArgs<ExtArgs>>): Prisma__joinerClient<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Joiners.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerCountArgs} args - Arguments to filter Joiners to count.
     * @example
     * // Count the number of Joiners
     * const count = await prisma.joiner.count({
     *   where: {
     *     // ... the filter for the Joiners we want to count
     *   }
     * })
    **/
    count<T extends joinerCountArgs>(
      args?: Subset<T, joinerCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], JoinerCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Joiner.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {JoinerAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends JoinerAggregateArgs>(args: Subset<T, JoinerAggregateArgs>): Prisma.PrismaPromise<GetJoinerAggregateType<T>>

    /**
     * Group by Joiner.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {joinerGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends joinerGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: joinerGroupByArgs['orderBy'] }
        : { orderBy?: joinerGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, joinerGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetJoinerGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the joiner model
   */
  readonly fields: joinerFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for joiner.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__joinerClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    trip<T extends tripDefaultArgs<ExtArgs> = {}>(args?: Subset<T, tripDefaultArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    account<T extends accountDefaultArgs<ExtArgs> = {}>(args?: Subset<T, accountDefaultArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findUniqueOrThrow"> | Null, Null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the joiner model
   */ 
  interface joinerFieldRefs {
    readonly IDTrip: FieldRef<"joiner", 'String'>
    readonly IDAccount: FieldRef<"joiner", 'String'>
    readonly type: FieldRef<"joiner", 'String'>
    readonly status: FieldRef<"joiner", 'String'>
  }
    

  // Custom InputTypes
  /**
   * joiner findUnique
   */
  export type joinerFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter, which joiner to fetch.
     */
    where: joinerWhereUniqueInput
  }

  /**
   * joiner findUniqueOrThrow
   */
  export type joinerFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter, which joiner to fetch.
     */
    where: joinerWhereUniqueInput
  }

  /**
   * joiner findFirst
   */
  export type joinerFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter, which joiner to fetch.
     */
    where?: joinerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of joiners to fetch.
     */
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for joiners.
     */
    cursor?: joinerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` joiners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` joiners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of joiners.
     */
    distinct?: JoinerScalarFieldEnum | JoinerScalarFieldEnum[]
  }

  /**
   * joiner findFirstOrThrow
   */
  export type joinerFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter, which joiner to fetch.
     */
    where?: joinerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of joiners to fetch.
     */
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for joiners.
     */
    cursor?: joinerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` joiners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` joiners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of joiners.
     */
    distinct?: JoinerScalarFieldEnum | JoinerScalarFieldEnum[]
  }

  /**
   * joiner findMany
   */
  export type joinerFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter, which joiners to fetch.
     */
    where?: joinerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of joiners to fetch.
     */
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing joiners.
     */
    cursor?: joinerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` joiners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` joiners.
     */
    skip?: number
    distinct?: JoinerScalarFieldEnum | JoinerScalarFieldEnum[]
  }

  /**
   * joiner create
   */
  export type joinerCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * The data needed to create a joiner.
     */
    data: XOR<joinerCreateInput, joinerUncheckedCreateInput>
  }

  /**
   * joiner createMany
   */
  export type joinerCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many joiners.
     */
    data: joinerCreateManyInput | joinerCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * joiner update
   */
  export type joinerUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * The data needed to update a joiner.
     */
    data: XOR<joinerUpdateInput, joinerUncheckedUpdateInput>
    /**
     * Choose, which joiner to update.
     */
    where: joinerWhereUniqueInput
  }

  /**
   * joiner updateMany
   */
  export type joinerUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update joiners.
     */
    data: XOR<joinerUpdateManyMutationInput, joinerUncheckedUpdateManyInput>
    /**
     * Filter which joiners to update
     */
    where?: joinerWhereInput
  }

  /**
   * joiner upsert
   */
  export type joinerUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * The filter to search for the joiner to update in case it exists.
     */
    where: joinerWhereUniqueInput
    /**
     * In case the joiner found by the `where` argument doesn't exist, create a new joiner with this data.
     */
    create: XOR<joinerCreateInput, joinerUncheckedCreateInput>
    /**
     * In case the joiner was found with the provided `where` argument, update it with this data.
     */
    update: XOR<joinerUpdateInput, joinerUncheckedUpdateInput>
  }

  /**
   * joiner delete
   */
  export type joinerDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    /**
     * Filter which joiner to delete.
     */
    where: joinerWhereUniqueInput
  }

  /**
   * joiner deleteMany
   */
  export type joinerDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which joiners to delete
     */
    where?: joinerWhereInput
  }

  /**
   * joiner without action
   */
  export type joinerDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
  }


  /**
   * Model trip
   */

  export type AggregateTrip = {
    _count: TripCountAggregateOutputType | null
    _avg: TripAvgAggregateOutputType | null
    _sum: TripSumAggregateOutputType | null
    _min: TripMinAggregateOutputType | null
    _max: TripMaxAggregateOutputType | null
  }

  export type TripAvgAggregateOutputType = {
    maxJoiner: number | null
    count: number | null
  }

  export type TripSumAggregateOutputType = {
    maxJoiner: number | null
    count: number | null
  }

  export type TripMinAggregateOutputType = {
    IDTrip: string | null
    IDOriginTrip: string | null
    IDAccount: string | null
    TripName: string | null
    Detail: string | null
    Preparation: string | null
    Booking: string | null
    createDate: Date | null
    lastEdit: Date | null
    private: boolean | null
    maxJoiner: number | null
    started: boolean | null
    count: number | null
  }

  export type TripMaxAggregateOutputType = {
    IDTrip: string | null
    IDOriginTrip: string | null
    IDAccount: string | null
    TripName: string | null
    Detail: string | null
    Preparation: string | null
    Booking: string | null
    createDate: Date | null
    lastEdit: Date | null
    private: boolean | null
    maxJoiner: number | null
    started: boolean | null
    count: number | null
  }

  export type TripCountAggregateOutputType = {
    IDTrip: number
    IDOriginTrip: number
    IDAccount: number
    TripName: number
    Detail: number
    Preparation: number
    Booking: number
    createDate: number
    lastEdit: number
    private: number
    maxJoiner: number
    started: number
    count: number
    _all: number
  }


  export type TripAvgAggregateInputType = {
    maxJoiner?: true
    count?: true
  }

  export type TripSumAggregateInputType = {
    maxJoiner?: true
    count?: true
  }

  export type TripMinAggregateInputType = {
    IDTrip?: true
    IDOriginTrip?: true
    IDAccount?: true
    TripName?: true
    Detail?: true
    Preparation?: true
    Booking?: true
    createDate?: true
    lastEdit?: true
    private?: true
    maxJoiner?: true
    started?: true
    count?: true
  }

  export type TripMaxAggregateInputType = {
    IDTrip?: true
    IDOriginTrip?: true
    IDAccount?: true
    TripName?: true
    Detail?: true
    Preparation?: true
    Booking?: true
    createDate?: true
    lastEdit?: true
    private?: true
    maxJoiner?: true
    started?: true
    count?: true
  }

  export type TripCountAggregateInputType = {
    IDTrip?: true
    IDOriginTrip?: true
    IDAccount?: true
    TripName?: true
    Detail?: true
    Preparation?: true
    Booking?: true
    createDate?: true
    lastEdit?: true
    private?: true
    maxJoiner?: true
    started?: true
    count?: true
    _all?: true
  }

  export type TripAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which trip to aggregate.
     */
    where?: tripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of trips to fetch.
     */
    orderBy?: tripOrderByWithRelationInput | tripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: tripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned trips
    **/
    _count?: true | TripCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TripAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TripSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TripMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TripMaxAggregateInputType
  }

  export type GetTripAggregateType<T extends TripAggregateArgs> = {
        [P in keyof T & keyof AggregateTrip]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTrip[P]>
      : GetScalarType<T[P], AggregateTrip[P]>
  }




  export type tripGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: tripWhereInput
    orderBy?: tripOrderByWithAggregationInput | tripOrderByWithAggregationInput[]
    by: TripScalarFieldEnum[] | TripScalarFieldEnum
    having?: tripScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TripCountAggregateInputType | true
    _avg?: TripAvgAggregateInputType
    _sum?: TripSumAggregateInputType
    _min?: TripMinAggregateInputType
    _max?: TripMaxAggregateInputType
  }

  export type TripGroupByOutputType = {
    IDTrip: string
    IDOriginTrip: string | null
    IDAccount: string | null
    TripName: string | null
    Detail: string | null
    Preparation: string | null
    Booking: string | null
    createDate: Date | null
    lastEdit: Date | null
    private: boolean | null
    maxJoiner: number | null
    started: boolean | null
    count: number | null
    _count: TripCountAggregateOutputType | null
    _avg: TripAvgAggregateOutputType | null
    _sum: TripSumAggregateOutputType | null
    _min: TripMinAggregateOutputType | null
    _max: TripMaxAggregateOutputType | null
  }

  type GetTripGroupByPayload<T extends tripGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TripGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TripGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TripGroupByOutputType[P]>
            : GetScalarType<T[P], TripGroupByOutputType[P]>
        }
      >
    >


  export type tripSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    IDTrip?: boolean
    IDOriginTrip?: boolean
    IDAccount?: boolean
    TripName?: boolean
    Detail?: boolean
    Preparation?: boolean
    Booking?: boolean
    createDate?: boolean
    lastEdit?: boolean
    private?: boolean
    maxJoiner?: boolean
    started?: boolean
    count?: boolean
    checkpoint?: boolean | trip$checkpointArgs<ExtArgs>
    joiner?: boolean | trip$joinerArgs<ExtArgs>
    account?: boolean | trip$accountArgs<ExtArgs>
    _count?: boolean | TripCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["trip"]>


  export type tripSelectScalar = {
    IDTrip?: boolean
    IDOriginTrip?: boolean
    IDAccount?: boolean
    TripName?: boolean
    Detail?: boolean
    Preparation?: boolean
    Booking?: boolean
    createDate?: boolean
    lastEdit?: boolean
    private?: boolean
    maxJoiner?: boolean
    started?: boolean
    count?: boolean
  }

  export type tripInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    checkpoint?: boolean | trip$checkpointArgs<ExtArgs>
    joiner?: boolean | trip$joinerArgs<ExtArgs>
    account?: boolean | trip$accountArgs<ExtArgs>
    _count?: boolean | TripCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $tripPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "trip"
    objects: {
      checkpoint: Prisma.$checkpointPayload<ExtArgs>[]
      joiner: Prisma.$joinerPayload<ExtArgs>[]
      account: Prisma.$accountPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      IDTrip: string
      IDOriginTrip: string | null
      IDAccount: string | null
      TripName: string | null
      Detail: string | null
      Preparation: string | null
      Booking: string | null
      createDate: Date | null
      lastEdit: Date | null
      private: boolean | null
      maxJoiner: number | null
      started: boolean | null
      count: number | null
    }, ExtArgs["result"]["trip"]>
    composites: {}
  }

  type tripGetPayload<S extends boolean | null | undefined | tripDefaultArgs> = $Result.GetResult<Prisma.$tripPayload, S>

  type tripCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = 
    Omit<tripFindManyArgs, 'select' | 'include' | 'distinct'> & {
      select?: TripCountAggregateInputType | true
    }

  export interface tripDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['trip'], meta: { name: 'trip' } }
    /**
     * Find zero or one Trip that matches the filter.
     * @param {tripFindUniqueArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends tripFindUniqueArgs>(args: SelectSubset<T, tripFindUniqueArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findUnique"> | null, null, ExtArgs>

    /**
     * Find one Trip that matches the filter or throw an error with `error.code='P2025'` 
     * if no matches were found.
     * @param {tripFindUniqueOrThrowArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends tripFindUniqueOrThrowArgs>(args: SelectSubset<T, tripFindUniqueOrThrowArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findUniqueOrThrow">, never, ExtArgs>

    /**
     * Find the first Trip that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripFindFirstArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends tripFindFirstArgs>(args?: SelectSubset<T, tripFindFirstArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findFirst"> | null, null, ExtArgs>

    /**
     * Find the first Trip that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripFindFirstOrThrowArgs} args - Arguments to find a Trip
     * @example
     * // Get one Trip
     * const trip = await prisma.trip.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends tripFindFirstOrThrowArgs>(args?: SelectSubset<T, tripFindFirstOrThrowArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findFirstOrThrow">, never, ExtArgs>

    /**
     * Find zero or more Trips that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Trips
     * const trips = await prisma.trip.findMany()
     * 
     * // Get first 10 Trips
     * const trips = await prisma.trip.findMany({ take: 10 })
     * 
     * // Only select the `IDTrip`
     * const tripWithIDTripOnly = await prisma.trip.findMany({ select: { IDTrip: true } })
     * 
     */
    findMany<T extends tripFindManyArgs>(args?: SelectSubset<T, tripFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "findMany">>

    /**
     * Create a Trip.
     * @param {tripCreateArgs} args - Arguments to create a Trip.
     * @example
     * // Create one Trip
     * const Trip = await prisma.trip.create({
     *   data: {
     *     // ... data to create a Trip
     *   }
     * })
     * 
     */
    create<T extends tripCreateArgs>(args: SelectSubset<T, tripCreateArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "create">, never, ExtArgs>

    /**
     * Create many Trips.
     * @param {tripCreateManyArgs} args - Arguments to create many Trips.
     * @example
     * // Create many Trips
     * const trip = await prisma.trip.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends tripCreateManyArgs>(args?: SelectSubset<T, tripCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Trip.
     * @param {tripDeleteArgs} args - Arguments to delete one Trip.
     * @example
     * // Delete one Trip
     * const Trip = await prisma.trip.delete({
     *   where: {
     *     // ... filter to delete one Trip
     *   }
     * })
     * 
     */
    delete<T extends tripDeleteArgs>(args: SelectSubset<T, tripDeleteArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "delete">, never, ExtArgs>

    /**
     * Update one Trip.
     * @param {tripUpdateArgs} args - Arguments to update one Trip.
     * @example
     * // Update one Trip
     * const trip = await prisma.trip.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends tripUpdateArgs>(args: SelectSubset<T, tripUpdateArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "update">, never, ExtArgs>

    /**
     * Delete zero or more Trips.
     * @param {tripDeleteManyArgs} args - Arguments to filter Trips to delete.
     * @example
     * // Delete a few Trips
     * const { count } = await prisma.trip.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends tripDeleteManyArgs>(args?: SelectSubset<T, tripDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Trips.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Trips
     * const trip = await prisma.trip.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends tripUpdateManyArgs>(args: SelectSubset<T, tripUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Trip.
     * @param {tripUpsertArgs} args - Arguments to update or create a Trip.
     * @example
     * // Update or create a Trip
     * const trip = await prisma.trip.upsert({
     *   create: {
     *     // ... data to create a Trip
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Trip we want to update
     *   }
     * })
     */
    upsert<T extends tripUpsertArgs>(args: SelectSubset<T, tripUpsertArgs<ExtArgs>>): Prisma__tripClient<$Result.GetResult<Prisma.$tripPayload<ExtArgs>, T, "upsert">, never, ExtArgs>


    /**
     * Count the number of Trips.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripCountArgs} args - Arguments to filter Trips to count.
     * @example
     * // Count the number of Trips
     * const count = await prisma.trip.count({
     *   where: {
     *     // ... the filter for the Trips we want to count
     *   }
     * })
    **/
    count<T extends tripCountArgs>(
      args?: Subset<T, tripCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TripCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Trip.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TripAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TripAggregateArgs>(args: Subset<T, TripAggregateArgs>): Prisma.PrismaPromise<GetTripAggregateType<T>>

    /**
     * Group by Trip.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tripGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends tripGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: tripGroupByArgs['orderBy'] }
        : { orderBy?: tripGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, tripGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTripGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the trip model
   */
  readonly fields: tripFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for trip.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__tripClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    checkpoint<T extends trip$checkpointArgs<ExtArgs> = {}>(args?: Subset<T, trip$checkpointArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$checkpointPayload<ExtArgs>, T, "findMany"> | Null>
    joiner<T extends trip$joinerArgs<ExtArgs> = {}>(args?: Subset<T, trip$joinerArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$joinerPayload<ExtArgs>, T, "findMany"> | Null>
    account<T extends trip$accountArgs<ExtArgs> = {}>(args?: Subset<T, trip$accountArgs<ExtArgs>>): Prisma__accountClient<$Result.GetResult<Prisma.$accountPayload<ExtArgs>, T, "findUniqueOrThrow"> | null, null, ExtArgs>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the trip model
   */ 
  interface tripFieldRefs {
    readonly IDTrip: FieldRef<"trip", 'String'>
    readonly IDOriginTrip: FieldRef<"trip", 'String'>
    readonly IDAccount: FieldRef<"trip", 'String'>
    readonly TripName: FieldRef<"trip", 'String'>
    readonly Detail: FieldRef<"trip", 'String'>
    readonly Preparation: FieldRef<"trip", 'String'>
    readonly Booking: FieldRef<"trip", 'String'>
    readonly createDate: FieldRef<"trip", 'DateTime'>
    readonly lastEdit: FieldRef<"trip", 'DateTime'>
    readonly private: FieldRef<"trip", 'Boolean'>
    readonly maxJoiner: FieldRef<"trip", 'Int'>
    readonly started: FieldRef<"trip", 'Boolean'>
    readonly count: FieldRef<"trip", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * trip findUnique
   */
  export type tripFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter, which trip to fetch.
     */
    where: tripWhereUniqueInput
  }

  /**
   * trip findUniqueOrThrow
   */
  export type tripFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter, which trip to fetch.
     */
    where: tripWhereUniqueInput
  }

  /**
   * trip findFirst
   */
  export type tripFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter, which trip to fetch.
     */
    where?: tripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of trips to fetch.
     */
    orderBy?: tripOrderByWithRelationInput | tripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for trips.
     */
    cursor?: tripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of trips.
     */
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * trip findFirstOrThrow
   */
  export type tripFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter, which trip to fetch.
     */
    where?: tripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of trips to fetch.
     */
    orderBy?: tripOrderByWithRelationInput | tripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for trips.
     */
    cursor?: tripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` trips.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of trips.
     */
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * trip findMany
   */
  export type tripFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter, which trips to fetch.
     */
    where?: tripWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of trips to fetch.
     */
    orderBy?: tripOrderByWithRelationInput | tripOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing trips.
     */
    cursor?: tripWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` trips from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` trips.
     */
    skip?: number
    distinct?: TripScalarFieldEnum | TripScalarFieldEnum[]
  }

  /**
   * trip create
   */
  export type tripCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * The data needed to create a trip.
     */
    data: XOR<tripCreateInput, tripUncheckedCreateInput>
  }

  /**
   * trip createMany
   */
  export type tripCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many trips.
     */
    data: tripCreateManyInput | tripCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * trip update
   */
  export type tripUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * The data needed to update a trip.
     */
    data: XOR<tripUpdateInput, tripUncheckedUpdateInput>
    /**
     * Choose, which trip to update.
     */
    where: tripWhereUniqueInput
  }

  /**
   * trip updateMany
   */
  export type tripUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update trips.
     */
    data: XOR<tripUpdateManyMutationInput, tripUncheckedUpdateManyInput>
    /**
     * Filter which trips to update
     */
    where?: tripWhereInput
  }

  /**
   * trip upsert
   */
  export type tripUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * The filter to search for the trip to update in case it exists.
     */
    where: tripWhereUniqueInput
    /**
     * In case the trip found by the `where` argument doesn't exist, create a new trip with this data.
     */
    create: XOR<tripCreateInput, tripUncheckedCreateInput>
    /**
     * In case the trip was found with the provided `where` argument, update it with this data.
     */
    update: XOR<tripUpdateInput, tripUncheckedUpdateInput>
  }

  /**
   * trip delete
   */
  export type tripDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
    /**
     * Filter which trip to delete.
     */
    where: tripWhereUniqueInput
  }

  /**
   * trip deleteMany
   */
  export type tripDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which trips to delete
     */
    where?: tripWhereInput
  }

  /**
   * trip.checkpoint
   */
  export type trip$checkpointArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the checkpoint
     */
    select?: checkpointSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: checkpointInclude<ExtArgs> | null
    where?: checkpointWhereInput
    orderBy?: checkpointOrderByWithRelationInput | checkpointOrderByWithRelationInput[]
    cursor?: checkpointWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CheckpointScalarFieldEnum | CheckpointScalarFieldEnum[]
  }

  /**
   * trip.joiner
   */
  export type trip$joinerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the joiner
     */
    select?: joinerSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: joinerInclude<ExtArgs> | null
    where?: joinerWhereInput
    orderBy?: joinerOrderByWithRelationInput | joinerOrderByWithRelationInput[]
    cursor?: joinerWhereUniqueInput
    take?: number
    skip?: number
    distinct?: JoinerScalarFieldEnum | JoinerScalarFieldEnum[]
  }

  /**
   * trip.account
   */
  export type trip$accountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the account
     */
    select?: accountSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: accountInclude<ExtArgs> | null
    where?: accountWhereInput
  }

  /**
   * trip without action
   */
  export type tripDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the trip
     */
    select?: tripSelect<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tripInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const AccountScalarFieldEnum: {
    IDAccount: 'IDAccount',
    IDGoogle: 'IDGoogle',
    Email: 'Email',
    Org: 'Org',
    imgURL: 'imgURL',
    name: 'name'
  };

  export type AccountScalarFieldEnum = (typeof AccountScalarFieldEnum)[keyof typeof AccountScalarFieldEnum]


  export const CheckpointScalarFieldEnum: {
    IDCheckpoint: 'IDCheckpoint',
    IDTrip: 'IDTrip',
    OrderC: 'OrderC',
    createTime: 'createTime',
    time: 'time',
    locationName: 'locationName',
    detail: 'detail',
    type: 'type'
  };

  export type CheckpointScalarFieldEnum = (typeof CheckpointScalarFieldEnum)[keyof typeof CheckpointScalarFieldEnum]


  export const JoinerScalarFieldEnum: {
    IDTrip: 'IDTrip',
    IDAccount: 'IDAccount',
    type: 'type',
    status: 'status'
  };

  export type JoinerScalarFieldEnum = (typeof JoinerScalarFieldEnum)[keyof typeof JoinerScalarFieldEnum]


  export const TripScalarFieldEnum: {
    IDTrip: 'IDTrip',
    IDOriginTrip: 'IDOriginTrip',
    IDAccount: 'IDAccount',
    TripName: 'TripName',
    Detail: 'Detail',
    Preparation: 'Preparation',
    Booking: 'Booking',
    createDate: 'createDate',
    lastEdit: 'lastEdit',
    private: 'private',
    maxJoiner: 'maxJoiner',
    started: 'started',
    count: 'count'
  };

  export type TripScalarFieldEnum = (typeof TripScalarFieldEnum)[keyof typeof TripScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references 
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type accountWhereInput = {
    AND?: accountWhereInput | accountWhereInput[]
    OR?: accountWhereInput[]
    NOT?: accountWhereInput | accountWhereInput[]
    IDAccount?: StringFilter<"account"> | string
    IDGoogle?: StringNullableFilter<"account"> | string | null
    Email?: StringNullableFilter<"account"> | string | null
    Org?: BoolNullableFilter<"account"> | boolean | null
    imgURL?: StringNullableFilter<"account"> | string | null
    name?: StringNullableFilter<"account"> | string | null
    joiner?: JoinerListRelationFilter
    trip?: TripListRelationFilter
  }

  export type accountOrderByWithRelationInput = {
    IDAccount?: SortOrder
    IDGoogle?: SortOrderInput | SortOrder
    Email?: SortOrderInput | SortOrder
    Org?: SortOrderInput | SortOrder
    imgURL?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    joiner?: joinerOrderByRelationAggregateInput
    trip?: tripOrderByRelationAggregateInput
  }

  export type accountWhereUniqueInput = Prisma.AtLeast<{
    IDAccount?: string
    AND?: accountWhereInput | accountWhereInput[]
    OR?: accountWhereInput[]
    NOT?: accountWhereInput | accountWhereInput[]
    IDGoogle?: StringNullableFilter<"account"> | string | null
    Email?: StringNullableFilter<"account"> | string | null
    Org?: BoolNullableFilter<"account"> | boolean | null
    imgURL?: StringNullableFilter<"account"> | string | null
    name?: StringNullableFilter<"account"> | string | null
    joiner?: JoinerListRelationFilter
    trip?: TripListRelationFilter
  }, "IDAccount">

  export type accountOrderByWithAggregationInput = {
    IDAccount?: SortOrder
    IDGoogle?: SortOrderInput | SortOrder
    Email?: SortOrderInput | SortOrder
    Org?: SortOrderInput | SortOrder
    imgURL?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    _count?: accountCountOrderByAggregateInput
    _max?: accountMaxOrderByAggregateInput
    _min?: accountMinOrderByAggregateInput
  }

  export type accountScalarWhereWithAggregatesInput = {
    AND?: accountScalarWhereWithAggregatesInput | accountScalarWhereWithAggregatesInput[]
    OR?: accountScalarWhereWithAggregatesInput[]
    NOT?: accountScalarWhereWithAggregatesInput | accountScalarWhereWithAggregatesInput[]
    IDAccount?: StringWithAggregatesFilter<"account"> | string
    IDGoogle?: StringNullableWithAggregatesFilter<"account"> | string | null
    Email?: StringNullableWithAggregatesFilter<"account"> | string | null
    Org?: BoolNullableWithAggregatesFilter<"account"> | boolean | null
    imgURL?: StringNullableWithAggregatesFilter<"account"> | string | null
    name?: StringNullableWithAggregatesFilter<"account"> | string | null
  }

  export type checkpointWhereInput = {
    AND?: checkpointWhereInput | checkpointWhereInput[]
    OR?: checkpointWhereInput[]
    NOT?: checkpointWhereInput | checkpointWhereInput[]
    IDCheckpoint?: StringFilter<"checkpoint"> | string
    IDTrip?: StringNullableFilter<"checkpoint"> | string | null
    OrderC?: IntNullableFilter<"checkpoint"> | number | null
    createTime?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    time?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    locationName?: StringNullableFilter<"checkpoint"> | string | null
    detail?: StringNullableFilter<"checkpoint"> | string | null
    type?: StringNullableFilter<"checkpoint"> | string | null
    trip?: XOR<TripNullableRelationFilter, tripWhereInput> | null
  }

  export type checkpointOrderByWithRelationInput = {
    IDCheckpoint?: SortOrder
    IDTrip?: SortOrderInput | SortOrder
    OrderC?: SortOrderInput | SortOrder
    createTime?: SortOrderInput | SortOrder
    time?: SortOrderInput | SortOrder
    locationName?: SortOrderInput | SortOrder
    detail?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    trip?: tripOrderByWithRelationInput
  }

  export type checkpointWhereUniqueInput = Prisma.AtLeast<{
    IDCheckpoint?: string
    AND?: checkpointWhereInput | checkpointWhereInput[]
    OR?: checkpointWhereInput[]
    NOT?: checkpointWhereInput | checkpointWhereInput[]
    IDTrip?: StringNullableFilter<"checkpoint"> | string | null
    OrderC?: IntNullableFilter<"checkpoint"> | number | null
    createTime?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    time?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    locationName?: StringNullableFilter<"checkpoint"> | string | null
    detail?: StringNullableFilter<"checkpoint"> | string | null
    type?: StringNullableFilter<"checkpoint"> | string | null
    trip?: XOR<TripNullableRelationFilter, tripWhereInput> | null
  }, "IDCheckpoint">

  export type checkpointOrderByWithAggregationInput = {
    IDCheckpoint?: SortOrder
    IDTrip?: SortOrderInput | SortOrder
    OrderC?: SortOrderInput | SortOrder
    createTime?: SortOrderInput | SortOrder
    time?: SortOrderInput | SortOrder
    locationName?: SortOrderInput | SortOrder
    detail?: SortOrderInput | SortOrder
    type?: SortOrderInput | SortOrder
    _count?: checkpointCountOrderByAggregateInput
    _avg?: checkpointAvgOrderByAggregateInput
    _max?: checkpointMaxOrderByAggregateInput
    _min?: checkpointMinOrderByAggregateInput
    _sum?: checkpointSumOrderByAggregateInput
  }

  export type checkpointScalarWhereWithAggregatesInput = {
    AND?: checkpointScalarWhereWithAggregatesInput | checkpointScalarWhereWithAggregatesInput[]
    OR?: checkpointScalarWhereWithAggregatesInput[]
    NOT?: checkpointScalarWhereWithAggregatesInput | checkpointScalarWhereWithAggregatesInput[]
    IDCheckpoint?: StringWithAggregatesFilter<"checkpoint"> | string
    IDTrip?: StringNullableWithAggregatesFilter<"checkpoint"> | string | null
    OrderC?: IntNullableWithAggregatesFilter<"checkpoint"> | number | null
    createTime?: DateTimeNullableWithAggregatesFilter<"checkpoint"> | Date | string | null
    time?: DateTimeNullableWithAggregatesFilter<"checkpoint"> | Date | string | null
    locationName?: StringNullableWithAggregatesFilter<"checkpoint"> | string | null
    detail?: StringNullableWithAggregatesFilter<"checkpoint"> | string | null
    type?: StringNullableWithAggregatesFilter<"checkpoint"> | string | null
  }

  export type joinerWhereInput = {
    AND?: joinerWhereInput | joinerWhereInput[]
    OR?: joinerWhereInput[]
    NOT?: joinerWhereInput | joinerWhereInput[]
    IDTrip?: StringFilter<"joiner"> | string
    IDAccount?: StringFilter<"joiner"> | string
    type?: StringNullableFilter<"joiner"> | string | null
    status?: StringNullableFilter<"joiner"> | string | null
    trip?: XOR<TripRelationFilter, tripWhereInput>
    account?: XOR<AccountRelationFilter, accountWhereInput>
  }

  export type joinerOrderByWithRelationInput = {
    IDTrip?: SortOrder
    IDAccount?: SortOrder
    type?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    trip?: tripOrderByWithRelationInput
    account?: accountOrderByWithRelationInput
  }

  export type joinerWhereUniqueInput = Prisma.AtLeast<{
    IDTrip_IDAccount?: joinerIDTripIDAccountCompoundUniqueInput
    AND?: joinerWhereInput | joinerWhereInput[]
    OR?: joinerWhereInput[]
    NOT?: joinerWhereInput | joinerWhereInput[]
    IDTrip?: StringFilter<"joiner"> | string
    IDAccount?: StringFilter<"joiner"> | string
    type?: StringNullableFilter<"joiner"> | string | null
    status?: StringNullableFilter<"joiner"> | string | null
    trip?: XOR<TripRelationFilter, tripWhereInput>
    account?: XOR<AccountRelationFilter, accountWhereInput>
  }, "IDTrip_IDAccount">

  export type joinerOrderByWithAggregationInput = {
    IDTrip?: SortOrder
    IDAccount?: SortOrder
    type?: SortOrderInput | SortOrder
    status?: SortOrderInput | SortOrder
    _count?: joinerCountOrderByAggregateInput
    _max?: joinerMaxOrderByAggregateInput
    _min?: joinerMinOrderByAggregateInput
  }

  export type joinerScalarWhereWithAggregatesInput = {
    AND?: joinerScalarWhereWithAggregatesInput | joinerScalarWhereWithAggregatesInput[]
    OR?: joinerScalarWhereWithAggregatesInput[]
    NOT?: joinerScalarWhereWithAggregatesInput | joinerScalarWhereWithAggregatesInput[]
    IDTrip?: StringWithAggregatesFilter<"joiner"> | string
    IDAccount?: StringWithAggregatesFilter<"joiner"> | string
    type?: StringNullableWithAggregatesFilter<"joiner"> | string | null
    status?: StringNullableWithAggregatesFilter<"joiner"> | string | null
  }

  export type tripWhereInput = {
    AND?: tripWhereInput | tripWhereInput[]
    OR?: tripWhereInput[]
    NOT?: tripWhereInput | tripWhereInput[]
    IDTrip?: StringFilter<"trip"> | string
    IDOriginTrip?: StringNullableFilter<"trip"> | string | null
    IDAccount?: StringNullableFilter<"trip"> | string | null
    TripName?: StringNullableFilter<"trip"> | string | null
    Detail?: StringNullableFilter<"trip"> | string | null
    Preparation?: StringNullableFilter<"trip"> | string | null
    Booking?: StringNullableFilter<"trip"> | string | null
    createDate?: DateTimeNullableFilter<"trip"> | Date | string | null
    lastEdit?: DateTimeNullableFilter<"trip"> | Date | string | null
    private?: BoolNullableFilter<"trip"> | boolean | null
    maxJoiner?: IntNullableFilter<"trip"> | number | null
    started?: BoolNullableFilter<"trip"> | boolean | null
    count?: IntNullableFilter<"trip"> | number | null
    checkpoint?: CheckpointListRelationFilter
    joiner?: JoinerListRelationFilter
    account?: XOR<AccountNullableRelationFilter, accountWhereInput> | null
  }

  export type tripOrderByWithRelationInput = {
    IDTrip?: SortOrder
    IDOriginTrip?: SortOrderInput | SortOrder
    IDAccount?: SortOrderInput | SortOrder
    TripName?: SortOrderInput | SortOrder
    Detail?: SortOrderInput | SortOrder
    Preparation?: SortOrderInput | SortOrder
    Booking?: SortOrderInput | SortOrder
    createDate?: SortOrderInput | SortOrder
    lastEdit?: SortOrderInput | SortOrder
    private?: SortOrderInput | SortOrder
    maxJoiner?: SortOrderInput | SortOrder
    started?: SortOrderInput | SortOrder
    count?: SortOrderInput | SortOrder
    checkpoint?: checkpointOrderByRelationAggregateInput
    joiner?: joinerOrderByRelationAggregateInput
    account?: accountOrderByWithRelationInput
  }

  export type tripWhereUniqueInput = Prisma.AtLeast<{
    IDTrip?: string
    AND?: tripWhereInput | tripWhereInput[]
    OR?: tripWhereInput[]
    NOT?: tripWhereInput | tripWhereInput[]
    IDOriginTrip?: StringNullableFilter<"trip"> | string | null
    IDAccount?: StringNullableFilter<"trip"> | string | null
    TripName?: StringNullableFilter<"trip"> | string | null
    Detail?: StringNullableFilter<"trip"> | string | null
    Preparation?: StringNullableFilter<"trip"> | string | null
    Booking?: StringNullableFilter<"trip"> | string | null
    createDate?: DateTimeNullableFilter<"trip"> | Date | string | null
    lastEdit?: DateTimeNullableFilter<"trip"> | Date | string | null
    private?: BoolNullableFilter<"trip"> | boolean | null
    maxJoiner?: IntNullableFilter<"trip"> | number | null
    started?: BoolNullableFilter<"trip"> | boolean | null
    count?: IntNullableFilter<"trip"> | number | null
    checkpoint?: CheckpointListRelationFilter
    joiner?: JoinerListRelationFilter
    account?: XOR<AccountNullableRelationFilter, accountWhereInput> | null
  }, "IDTrip">

  export type tripOrderByWithAggregationInput = {
    IDTrip?: SortOrder
    IDOriginTrip?: SortOrderInput | SortOrder
    IDAccount?: SortOrderInput | SortOrder
    TripName?: SortOrderInput | SortOrder
    Detail?: SortOrderInput | SortOrder
    Preparation?: SortOrderInput | SortOrder
    Booking?: SortOrderInput | SortOrder
    createDate?: SortOrderInput | SortOrder
    lastEdit?: SortOrderInput | SortOrder
    private?: SortOrderInput | SortOrder
    maxJoiner?: SortOrderInput | SortOrder
    started?: SortOrderInput | SortOrder
    count?: SortOrderInput | SortOrder
    _count?: tripCountOrderByAggregateInput
    _avg?: tripAvgOrderByAggregateInput
    _max?: tripMaxOrderByAggregateInput
    _min?: tripMinOrderByAggregateInput
    _sum?: tripSumOrderByAggregateInput
  }

  export type tripScalarWhereWithAggregatesInput = {
    AND?: tripScalarWhereWithAggregatesInput | tripScalarWhereWithAggregatesInput[]
    OR?: tripScalarWhereWithAggregatesInput[]
    NOT?: tripScalarWhereWithAggregatesInput | tripScalarWhereWithAggregatesInput[]
    IDTrip?: StringWithAggregatesFilter<"trip"> | string
    IDOriginTrip?: StringNullableWithAggregatesFilter<"trip"> | string | null
    IDAccount?: StringNullableWithAggregatesFilter<"trip"> | string | null
    TripName?: StringNullableWithAggregatesFilter<"trip"> | string | null
    Detail?: StringNullableWithAggregatesFilter<"trip"> | string | null
    Preparation?: StringNullableWithAggregatesFilter<"trip"> | string | null
    Booking?: StringNullableWithAggregatesFilter<"trip"> | string | null
    createDate?: DateTimeNullableWithAggregatesFilter<"trip"> | Date | string | null
    lastEdit?: DateTimeNullableWithAggregatesFilter<"trip"> | Date | string | null
    private?: BoolNullableWithAggregatesFilter<"trip"> | boolean | null
    maxJoiner?: IntNullableWithAggregatesFilter<"trip"> | number | null
    started?: BoolNullableWithAggregatesFilter<"trip"> | boolean | null
    count?: IntNullableWithAggregatesFilter<"trip"> | number | null
  }

  export type accountCreateInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    joiner?: joinerCreateNestedManyWithoutAccountInput
    trip?: tripCreateNestedManyWithoutAccountInput
  }

  export type accountUncheckedCreateInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    joiner?: joinerUncheckedCreateNestedManyWithoutAccountInput
    trip?: tripUncheckedCreateNestedManyWithoutAccountInput
  }

  export type accountUpdateInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    joiner?: joinerUpdateManyWithoutAccountNestedInput
    trip?: tripUpdateManyWithoutAccountNestedInput
  }

  export type accountUncheckedUpdateInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    joiner?: joinerUncheckedUpdateManyWithoutAccountNestedInput
    trip?: tripUncheckedUpdateManyWithoutAccountNestedInput
  }

  export type accountCreateManyInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
  }

  export type accountUpdateManyMutationInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type accountUncheckedUpdateManyInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type checkpointCreateInput = {
    IDCheckpoint: string
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
    trip?: tripCreateNestedOneWithoutCheckpointInput
  }

  export type checkpointUncheckedCreateInput = {
    IDCheckpoint: string
    IDTrip?: string | null
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
  }

  export type checkpointUpdateInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
    trip?: tripUpdateOneWithoutCheckpointNestedInput
  }

  export type checkpointUncheckedUpdateInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    IDTrip?: NullableStringFieldUpdateOperationsInput | string | null
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type checkpointCreateManyInput = {
    IDCheckpoint: string
    IDTrip?: string | null
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
  }

  export type checkpointUpdateManyMutationInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type checkpointUncheckedUpdateManyInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    IDTrip?: NullableStringFieldUpdateOperationsInput | string | null
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerCreateInput = {
    type?: string | null
    status?: string | null
    trip: tripCreateNestedOneWithoutJoinerInput
    account: accountCreateNestedOneWithoutJoinerInput
  }

  export type joinerUncheckedCreateInput = {
    IDTrip: string
    IDAccount: string
    type?: string | null
    status?: string | null
  }

  export type joinerUpdateInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    trip?: tripUpdateOneRequiredWithoutJoinerNestedInput
    account?: accountUpdateOneRequiredWithoutJoinerNestedInput
  }

  export type joinerUncheckedUpdateInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDAccount?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerCreateManyInput = {
    IDTrip: string
    IDAccount: string
    type?: string | null
    status?: string | null
  }

  export type joinerUpdateManyMutationInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerUncheckedUpdateManyInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDAccount?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type tripCreateInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointCreateNestedManyWithoutTripInput
    joiner?: joinerCreateNestedManyWithoutTripInput
    account?: accountCreateNestedOneWithoutTripInput
  }

  export type tripUncheckedCreateInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    IDAccount?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointUncheckedCreateNestedManyWithoutTripInput
    joiner?: joinerUncheckedCreateNestedManyWithoutTripInput
  }

  export type tripUpdateInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUpdateManyWithoutTripNestedInput
    joiner?: joinerUpdateManyWithoutTripNestedInput
    account?: accountUpdateOneWithoutTripNestedInput
  }

  export type tripUncheckedUpdateInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    IDAccount?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUncheckedUpdateManyWithoutTripNestedInput
    joiner?: joinerUncheckedUpdateManyWithoutTripNestedInput
  }

  export type tripCreateManyInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    IDAccount?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
  }

  export type tripUpdateManyMutationInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type tripUncheckedUpdateManyInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    IDAccount?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type BoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type JoinerListRelationFilter = {
    every?: joinerWhereInput
    some?: joinerWhereInput
    none?: joinerWhereInput
  }

  export type TripListRelationFilter = {
    every?: tripWhereInput
    some?: tripWhereInput
    none?: tripWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type joinerOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type tripOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type accountCountOrderByAggregateInput = {
    IDAccount?: SortOrder
    IDGoogle?: SortOrder
    Email?: SortOrder
    Org?: SortOrder
    imgURL?: SortOrder
    name?: SortOrder
  }

  export type accountMaxOrderByAggregateInput = {
    IDAccount?: SortOrder
    IDGoogle?: SortOrder
    Email?: SortOrder
    Org?: SortOrder
    imgURL?: SortOrder
    name?: SortOrder
  }

  export type accountMinOrderByAggregateInput = {
    IDAccount?: SortOrder
    IDGoogle?: SortOrder
    Email?: SortOrder
    Org?: SortOrder
    imgURL?: SortOrder
    name?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type BoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type TripNullableRelationFilter = {
    is?: tripWhereInput | null
    isNot?: tripWhereInput | null
  }

  export type checkpointCountOrderByAggregateInput = {
    IDCheckpoint?: SortOrder
    IDTrip?: SortOrder
    OrderC?: SortOrder
    createTime?: SortOrder
    time?: SortOrder
    locationName?: SortOrder
    detail?: SortOrder
    type?: SortOrder
  }

  export type checkpointAvgOrderByAggregateInput = {
    OrderC?: SortOrder
  }

  export type checkpointMaxOrderByAggregateInput = {
    IDCheckpoint?: SortOrder
    IDTrip?: SortOrder
    OrderC?: SortOrder
    createTime?: SortOrder
    time?: SortOrder
    locationName?: SortOrder
    detail?: SortOrder
    type?: SortOrder
  }

  export type checkpointMinOrderByAggregateInput = {
    IDCheckpoint?: SortOrder
    IDTrip?: SortOrder
    OrderC?: SortOrder
    createTime?: SortOrder
    time?: SortOrder
    locationName?: SortOrder
    detail?: SortOrder
    type?: SortOrder
  }

  export type checkpointSumOrderByAggregateInput = {
    OrderC?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type TripRelationFilter = {
    is?: tripWhereInput
    isNot?: tripWhereInput
  }

  export type AccountRelationFilter = {
    is?: accountWhereInput
    isNot?: accountWhereInput
  }

  export type joinerIDTripIDAccountCompoundUniqueInput = {
    IDTrip: string
    IDAccount: string
  }

  export type joinerCountOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDAccount?: SortOrder
    type?: SortOrder
    status?: SortOrder
  }

  export type joinerMaxOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDAccount?: SortOrder
    type?: SortOrder
    status?: SortOrder
  }

  export type joinerMinOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDAccount?: SortOrder
    type?: SortOrder
    status?: SortOrder
  }

  export type CheckpointListRelationFilter = {
    every?: checkpointWhereInput
    some?: checkpointWhereInput
    none?: checkpointWhereInput
  }

  export type AccountNullableRelationFilter = {
    is?: accountWhereInput | null
    isNot?: accountWhereInput | null
  }

  export type checkpointOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type tripCountOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDOriginTrip?: SortOrder
    IDAccount?: SortOrder
    TripName?: SortOrder
    Detail?: SortOrder
    Preparation?: SortOrder
    Booking?: SortOrder
    createDate?: SortOrder
    lastEdit?: SortOrder
    private?: SortOrder
    maxJoiner?: SortOrder
    started?: SortOrder
    count?: SortOrder
  }

  export type tripAvgOrderByAggregateInput = {
    maxJoiner?: SortOrder
    count?: SortOrder
  }

  export type tripMaxOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDOriginTrip?: SortOrder
    IDAccount?: SortOrder
    TripName?: SortOrder
    Detail?: SortOrder
    Preparation?: SortOrder
    Booking?: SortOrder
    createDate?: SortOrder
    lastEdit?: SortOrder
    private?: SortOrder
    maxJoiner?: SortOrder
    started?: SortOrder
    count?: SortOrder
  }

  export type tripMinOrderByAggregateInput = {
    IDTrip?: SortOrder
    IDOriginTrip?: SortOrder
    IDAccount?: SortOrder
    TripName?: SortOrder
    Detail?: SortOrder
    Preparation?: SortOrder
    Booking?: SortOrder
    createDate?: SortOrder
    lastEdit?: SortOrder
    private?: SortOrder
    maxJoiner?: SortOrder
    started?: SortOrder
    count?: SortOrder
  }

  export type tripSumOrderByAggregateInput = {
    maxJoiner?: SortOrder
    count?: SortOrder
  }

  export type joinerCreateNestedManyWithoutAccountInput = {
    create?: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput> | joinerCreateWithoutAccountInput[] | joinerUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutAccountInput | joinerCreateOrConnectWithoutAccountInput[]
    createMany?: joinerCreateManyAccountInputEnvelope
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
  }

  export type tripCreateNestedManyWithoutAccountInput = {
    create?: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput> | tripCreateWithoutAccountInput[] | tripUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: tripCreateOrConnectWithoutAccountInput | tripCreateOrConnectWithoutAccountInput[]
    createMany?: tripCreateManyAccountInputEnvelope
    connect?: tripWhereUniqueInput | tripWhereUniqueInput[]
  }

  export type joinerUncheckedCreateNestedManyWithoutAccountInput = {
    create?: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput> | joinerCreateWithoutAccountInput[] | joinerUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutAccountInput | joinerCreateOrConnectWithoutAccountInput[]
    createMany?: joinerCreateManyAccountInputEnvelope
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
  }

  export type tripUncheckedCreateNestedManyWithoutAccountInput = {
    create?: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput> | tripCreateWithoutAccountInput[] | tripUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: tripCreateOrConnectWithoutAccountInput | tripCreateOrConnectWithoutAccountInput[]
    createMany?: tripCreateManyAccountInputEnvelope
    connect?: tripWhereUniqueInput | tripWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type joinerUpdateManyWithoutAccountNestedInput = {
    create?: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput> | joinerCreateWithoutAccountInput[] | joinerUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutAccountInput | joinerCreateOrConnectWithoutAccountInput[]
    upsert?: joinerUpsertWithWhereUniqueWithoutAccountInput | joinerUpsertWithWhereUniqueWithoutAccountInput[]
    createMany?: joinerCreateManyAccountInputEnvelope
    set?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    disconnect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    delete?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    update?: joinerUpdateWithWhereUniqueWithoutAccountInput | joinerUpdateWithWhereUniqueWithoutAccountInput[]
    updateMany?: joinerUpdateManyWithWhereWithoutAccountInput | joinerUpdateManyWithWhereWithoutAccountInput[]
    deleteMany?: joinerScalarWhereInput | joinerScalarWhereInput[]
  }

  export type tripUpdateManyWithoutAccountNestedInput = {
    create?: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput> | tripCreateWithoutAccountInput[] | tripUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: tripCreateOrConnectWithoutAccountInput | tripCreateOrConnectWithoutAccountInput[]
    upsert?: tripUpsertWithWhereUniqueWithoutAccountInput | tripUpsertWithWhereUniqueWithoutAccountInput[]
    createMany?: tripCreateManyAccountInputEnvelope
    set?: tripWhereUniqueInput | tripWhereUniqueInput[]
    disconnect?: tripWhereUniqueInput | tripWhereUniqueInput[]
    delete?: tripWhereUniqueInput | tripWhereUniqueInput[]
    connect?: tripWhereUniqueInput | tripWhereUniqueInput[]
    update?: tripUpdateWithWhereUniqueWithoutAccountInput | tripUpdateWithWhereUniqueWithoutAccountInput[]
    updateMany?: tripUpdateManyWithWhereWithoutAccountInput | tripUpdateManyWithWhereWithoutAccountInput[]
    deleteMany?: tripScalarWhereInput | tripScalarWhereInput[]
  }

  export type joinerUncheckedUpdateManyWithoutAccountNestedInput = {
    create?: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput> | joinerCreateWithoutAccountInput[] | joinerUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutAccountInput | joinerCreateOrConnectWithoutAccountInput[]
    upsert?: joinerUpsertWithWhereUniqueWithoutAccountInput | joinerUpsertWithWhereUniqueWithoutAccountInput[]
    createMany?: joinerCreateManyAccountInputEnvelope
    set?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    disconnect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    delete?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    update?: joinerUpdateWithWhereUniqueWithoutAccountInput | joinerUpdateWithWhereUniqueWithoutAccountInput[]
    updateMany?: joinerUpdateManyWithWhereWithoutAccountInput | joinerUpdateManyWithWhereWithoutAccountInput[]
    deleteMany?: joinerScalarWhereInput | joinerScalarWhereInput[]
  }

  export type tripUncheckedUpdateManyWithoutAccountNestedInput = {
    create?: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput> | tripCreateWithoutAccountInput[] | tripUncheckedCreateWithoutAccountInput[]
    connectOrCreate?: tripCreateOrConnectWithoutAccountInput | tripCreateOrConnectWithoutAccountInput[]
    upsert?: tripUpsertWithWhereUniqueWithoutAccountInput | tripUpsertWithWhereUniqueWithoutAccountInput[]
    createMany?: tripCreateManyAccountInputEnvelope
    set?: tripWhereUniqueInput | tripWhereUniqueInput[]
    disconnect?: tripWhereUniqueInput | tripWhereUniqueInput[]
    delete?: tripWhereUniqueInput | tripWhereUniqueInput[]
    connect?: tripWhereUniqueInput | tripWhereUniqueInput[]
    update?: tripUpdateWithWhereUniqueWithoutAccountInput | tripUpdateWithWhereUniqueWithoutAccountInput[]
    updateMany?: tripUpdateManyWithWhereWithoutAccountInput | tripUpdateManyWithWhereWithoutAccountInput[]
    deleteMany?: tripScalarWhereInput | tripScalarWhereInput[]
  }

  export type tripCreateNestedOneWithoutCheckpointInput = {
    create?: XOR<tripCreateWithoutCheckpointInput, tripUncheckedCreateWithoutCheckpointInput>
    connectOrCreate?: tripCreateOrConnectWithoutCheckpointInput
    connect?: tripWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type tripUpdateOneWithoutCheckpointNestedInput = {
    create?: XOR<tripCreateWithoutCheckpointInput, tripUncheckedCreateWithoutCheckpointInput>
    connectOrCreate?: tripCreateOrConnectWithoutCheckpointInput
    upsert?: tripUpsertWithoutCheckpointInput
    disconnect?: tripWhereInput | boolean
    delete?: tripWhereInput | boolean
    connect?: tripWhereUniqueInput
    update?: XOR<XOR<tripUpdateToOneWithWhereWithoutCheckpointInput, tripUpdateWithoutCheckpointInput>, tripUncheckedUpdateWithoutCheckpointInput>
  }

  export type tripCreateNestedOneWithoutJoinerInput = {
    create?: XOR<tripCreateWithoutJoinerInput, tripUncheckedCreateWithoutJoinerInput>
    connectOrCreate?: tripCreateOrConnectWithoutJoinerInput
    connect?: tripWhereUniqueInput
  }

  export type accountCreateNestedOneWithoutJoinerInput = {
    create?: XOR<accountCreateWithoutJoinerInput, accountUncheckedCreateWithoutJoinerInput>
    connectOrCreate?: accountCreateOrConnectWithoutJoinerInput
    connect?: accountWhereUniqueInput
  }

  export type tripUpdateOneRequiredWithoutJoinerNestedInput = {
    create?: XOR<tripCreateWithoutJoinerInput, tripUncheckedCreateWithoutJoinerInput>
    connectOrCreate?: tripCreateOrConnectWithoutJoinerInput
    upsert?: tripUpsertWithoutJoinerInput
    connect?: tripWhereUniqueInput
    update?: XOR<XOR<tripUpdateToOneWithWhereWithoutJoinerInput, tripUpdateWithoutJoinerInput>, tripUncheckedUpdateWithoutJoinerInput>
  }

  export type accountUpdateOneRequiredWithoutJoinerNestedInput = {
    create?: XOR<accountCreateWithoutJoinerInput, accountUncheckedCreateWithoutJoinerInput>
    connectOrCreate?: accountCreateOrConnectWithoutJoinerInput
    upsert?: accountUpsertWithoutJoinerInput
    connect?: accountWhereUniqueInput
    update?: XOR<XOR<accountUpdateToOneWithWhereWithoutJoinerInput, accountUpdateWithoutJoinerInput>, accountUncheckedUpdateWithoutJoinerInput>
  }

  export type checkpointCreateNestedManyWithoutTripInput = {
    create?: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput> | checkpointCreateWithoutTripInput[] | checkpointUncheckedCreateWithoutTripInput[]
    connectOrCreate?: checkpointCreateOrConnectWithoutTripInput | checkpointCreateOrConnectWithoutTripInput[]
    createMany?: checkpointCreateManyTripInputEnvelope
    connect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
  }

  export type joinerCreateNestedManyWithoutTripInput = {
    create?: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput> | joinerCreateWithoutTripInput[] | joinerUncheckedCreateWithoutTripInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutTripInput | joinerCreateOrConnectWithoutTripInput[]
    createMany?: joinerCreateManyTripInputEnvelope
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
  }

  export type accountCreateNestedOneWithoutTripInput = {
    create?: XOR<accountCreateWithoutTripInput, accountUncheckedCreateWithoutTripInput>
    connectOrCreate?: accountCreateOrConnectWithoutTripInput
    connect?: accountWhereUniqueInput
  }

  export type checkpointUncheckedCreateNestedManyWithoutTripInput = {
    create?: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput> | checkpointCreateWithoutTripInput[] | checkpointUncheckedCreateWithoutTripInput[]
    connectOrCreate?: checkpointCreateOrConnectWithoutTripInput | checkpointCreateOrConnectWithoutTripInput[]
    createMany?: checkpointCreateManyTripInputEnvelope
    connect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
  }

  export type joinerUncheckedCreateNestedManyWithoutTripInput = {
    create?: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput> | joinerCreateWithoutTripInput[] | joinerUncheckedCreateWithoutTripInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutTripInput | joinerCreateOrConnectWithoutTripInput[]
    createMany?: joinerCreateManyTripInputEnvelope
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
  }

  export type checkpointUpdateManyWithoutTripNestedInput = {
    create?: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput> | checkpointCreateWithoutTripInput[] | checkpointUncheckedCreateWithoutTripInput[]
    connectOrCreate?: checkpointCreateOrConnectWithoutTripInput | checkpointCreateOrConnectWithoutTripInput[]
    upsert?: checkpointUpsertWithWhereUniqueWithoutTripInput | checkpointUpsertWithWhereUniqueWithoutTripInput[]
    createMany?: checkpointCreateManyTripInputEnvelope
    set?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    disconnect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    delete?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    connect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    update?: checkpointUpdateWithWhereUniqueWithoutTripInput | checkpointUpdateWithWhereUniqueWithoutTripInput[]
    updateMany?: checkpointUpdateManyWithWhereWithoutTripInput | checkpointUpdateManyWithWhereWithoutTripInput[]
    deleteMany?: checkpointScalarWhereInput | checkpointScalarWhereInput[]
  }

  export type joinerUpdateManyWithoutTripNestedInput = {
    create?: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput> | joinerCreateWithoutTripInput[] | joinerUncheckedCreateWithoutTripInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutTripInput | joinerCreateOrConnectWithoutTripInput[]
    upsert?: joinerUpsertWithWhereUniqueWithoutTripInput | joinerUpsertWithWhereUniqueWithoutTripInput[]
    createMany?: joinerCreateManyTripInputEnvelope
    set?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    disconnect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    delete?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    update?: joinerUpdateWithWhereUniqueWithoutTripInput | joinerUpdateWithWhereUniqueWithoutTripInput[]
    updateMany?: joinerUpdateManyWithWhereWithoutTripInput | joinerUpdateManyWithWhereWithoutTripInput[]
    deleteMany?: joinerScalarWhereInput | joinerScalarWhereInput[]
  }

  export type accountUpdateOneWithoutTripNestedInput = {
    create?: XOR<accountCreateWithoutTripInput, accountUncheckedCreateWithoutTripInput>
    connectOrCreate?: accountCreateOrConnectWithoutTripInput
    upsert?: accountUpsertWithoutTripInput
    disconnect?: accountWhereInput | boolean
    delete?: accountWhereInput | boolean
    connect?: accountWhereUniqueInput
    update?: XOR<XOR<accountUpdateToOneWithWhereWithoutTripInput, accountUpdateWithoutTripInput>, accountUncheckedUpdateWithoutTripInput>
  }

  export type checkpointUncheckedUpdateManyWithoutTripNestedInput = {
    create?: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput> | checkpointCreateWithoutTripInput[] | checkpointUncheckedCreateWithoutTripInput[]
    connectOrCreate?: checkpointCreateOrConnectWithoutTripInput | checkpointCreateOrConnectWithoutTripInput[]
    upsert?: checkpointUpsertWithWhereUniqueWithoutTripInput | checkpointUpsertWithWhereUniqueWithoutTripInput[]
    createMany?: checkpointCreateManyTripInputEnvelope
    set?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    disconnect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    delete?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    connect?: checkpointWhereUniqueInput | checkpointWhereUniqueInput[]
    update?: checkpointUpdateWithWhereUniqueWithoutTripInput | checkpointUpdateWithWhereUniqueWithoutTripInput[]
    updateMany?: checkpointUpdateManyWithWhereWithoutTripInput | checkpointUpdateManyWithWhereWithoutTripInput[]
    deleteMany?: checkpointScalarWhereInput | checkpointScalarWhereInput[]
  }

  export type joinerUncheckedUpdateManyWithoutTripNestedInput = {
    create?: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput> | joinerCreateWithoutTripInput[] | joinerUncheckedCreateWithoutTripInput[]
    connectOrCreate?: joinerCreateOrConnectWithoutTripInput | joinerCreateOrConnectWithoutTripInput[]
    upsert?: joinerUpsertWithWhereUniqueWithoutTripInput | joinerUpsertWithWhereUniqueWithoutTripInput[]
    createMany?: joinerCreateManyTripInputEnvelope
    set?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    disconnect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    delete?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    connect?: joinerWhereUniqueInput | joinerWhereUniqueInput[]
    update?: joinerUpdateWithWhereUniqueWithoutTripInput | joinerUpdateWithWhereUniqueWithoutTripInput[]
    updateMany?: joinerUpdateManyWithWhereWithoutTripInput | joinerUpdateManyWithWhereWithoutTripInput[]
    deleteMany?: joinerScalarWhereInput | joinerScalarWhereInput[]
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedBoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type joinerCreateWithoutAccountInput = {
    type?: string | null
    status?: string | null
    trip: tripCreateNestedOneWithoutJoinerInput
  }

  export type joinerUncheckedCreateWithoutAccountInput = {
    IDTrip: string
    type?: string | null
    status?: string | null
  }

  export type joinerCreateOrConnectWithoutAccountInput = {
    where: joinerWhereUniqueInput
    create: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput>
  }

  export type joinerCreateManyAccountInputEnvelope = {
    data: joinerCreateManyAccountInput | joinerCreateManyAccountInput[]
    skipDuplicates?: boolean
  }

  export type tripCreateWithoutAccountInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointCreateNestedManyWithoutTripInput
    joiner?: joinerCreateNestedManyWithoutTripInput
  }

  export type tripUncheckedCreateWithoutAccountInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointUncheckedCreateNestedManyWithoutTripInput
    joiner?: joinerUncheckedCreateNestedManyWithoutTripInput
  }

  export type tripCreateOrConnectWithoutAccountInput = {
    where: tripWhereUniqueInput
    create: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput>
  }

  export type tripCreateManyAccountInputEnvelope = {
    data: tripCreateManyAccountInput | tripCreateManyAccountInput[]
    skipDuplicates?: boolean
  }

  export type joinerUpsertWithWhereUniqueWithoutAccountInput = {
    where: joinerWhereUniqueInput
    update: XOR<joinerUpdateWithoutAccountInput, joinerUncheckedUpdateWithoutAccountInput>
    create: XOR<joinerCreateWithoutAccountInput, joinerUncheckedCreateWithoutAccountInput>
  }

  export type joinerUpdateWithWhereUniqueWithoutAccountInput = {
    where: joinerWhereUniqueInput
    data: XOR<joinerUpdateWithoutAccountInput, joinerUncheckedUpdateWithoutAccountInput>
  }

  export type joinerUpdateManyWithWhereWithoutAccountInput = {
    where: joinerScalarWhereInput
    data: XOR<joinerUpdateManyMutationInput, joinerUncheckedUpdateManyWithoutAccountInput>
  }

  export type joinerScalarWhereInput = {
    AND?: joinerScalarWhereInput | joinerScalarWhereInput[]
    OR?: joinerScalarWhereInput[]
    NOT?: joinerScalarWhereInput | joinerScalarWhereInput[]
    IDTrip?: StringFilter<"joiner"> | string
    IDAccount?: StringFilter<"joiner"> | string
    type?: StringNullableFilter<"joiner"> | string | null
    status?: StringNullableFilter<"joiner"> | string | null
  }

  export type tripUpsertWithWhereUniqueWithoutAccountInput = {
    where: tripWhereUniqueInput
    update: XOR<tripUpdateWithoutAccountInput, tripUncheckedUpdateWithoutAccountInput>
    create: XOR<tripCreateWithoutAccountInput, tripUncheckedCreateWithoutAccountInput>
  }

  export type tripUpdateWithWhereUniqueWithoutAccountInput = {
    where: tripWhereUniqueInput
    data: XOR<tripUpdateWithoutAccountInput, tripUncheckedUpdateWithoutAccountInput>
  }

  export type tripUpdateManyWithWhereWithoutAccountInput = {
    where: tripScalarWhereInput
    data: XOR<tripUpdateManyMutationInput, tripUncheckedUpdateManyWithoutAccountInput>
  }

  export type tripScalarWhereInput = {
    AND?: tripScalarWhereInput | tripScalarWhereInput[]
    OR?: tripScalarWhereInput[]
    NOT?: tripScalarWhereInput | tripScalarWhereInput[]
    IDTrip?: StringFilter<"trip"> | string
    IDOriginTrip?: StringNullableFilter<"trip"> | string | null
    IDAccount?: StringNullableFilter<"trip"> | string | null
    TripName?: StringNullableFilter<"trip"> | string | null
    Detail?: StringNullableFilter<"trip"> | string | null
    Preparation?: StringNullableFilter<"trip"> | string | null
    Booking?: StringNullableFilter<"trip"> | string | null
    createDate?: DateTimeNullableFilter<"trip"> | Date | string | null
    lastEdit?: DateTimeNullableFilter<"trip"> | Date | string | null
    private?: BoolNullableFilter<"trip"> | boolean | null
    maxJoiner?: IntNullableFilter<"trip"> | number | null
    started?: BoolNullableFilter<"trip"> | boolean | null
    count?: IntNullableFilter<"trip"> | number | null
  }

  export type tripCreateWithoutCheckpointInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    joiner?: joinerCreateNestedManyWithoutTripInput
    account?: accountCreateNestedOneWithoutTripInput
  }

  export type tripUncheckedCreateWithoutCheckpointInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    IDAccount?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    joiner?: joinerUncheckedCreateNestedManyWithoutTripInput
  }

  export type tripCreateOrConnectWithoutCheckpointInput = {
    where: tripWhereUniqueInput
    create: XOR<tripCreateWithoutCheckpointInput, tripUncheckedCreateWithoutCheckpointInput>
  }

  export type tripUpsertWithoutCheckpointInput = {
    update: XOR<tripUpdateWithoutCheckpointInput, tripUncheckedUpdateWithoutCheckpointInput>
    create: XOR<tripCreateWithoutCheckpointInput, tripUncheckedCreateWithoutCheckpointInput>
    where?: tripWhereInput
  }

  export type tripUpdateToOneWithWhereWithoutCheckpointInput = {
    where?: tripWhereInput
    data: XOR<tripUpdateWithoutCheckpointInput, tripUncheckedUpdateWithoutCheckpointInput>
  }

  export type tripUpdateWithoutCheckpointInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    joiner?: joinerUpdateManyWithoutTripNestedInput
    account?: accountUpdateOneWithoutTripNestedInput
  }

  export type tripUncheckedUpdateWithoutCheckpointInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    IDAccount?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    joiner?: joinerUncheckedUpdateManyWithoutTripNestedInput
  }

  export type tripCreateWithoutJoinerInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointCreateNestedManyWithoutTripInput
    account?: accountCreateNestedOneWithoutTripInput
  }

  export type tripUncheckedCreateWithoutJoinerInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    IDAccount?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
    checkpoint?: checkpointUncheckedCreateNestedManyWithoutTripInput
  }

  export type tripCreateOrConnectWithoutJoinerInput = {
    where: tripWhereUniqueInput
    create: XOR<tripCreateWithoutJoinerInput, tripUncheckedCreateWithoutJoinerInput>
  }

  export type accountCreateWithoutJoinerInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    trip?: tripCreateNestedManyWithoutAccountInput
  }

  export type accountUncheckedCreateWithoutJoinerInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    trip?: tripUncheckedCreateNestedManyWithoutAccountInput
  }

  export type accountCreateOrConnectWithoutJoinerInput = {
    where: accountWhereUniqueInput
    create: XOR<accountCreateWithoutJoinerInput, accountUncheckedCreateWithoutJoinerInput>
  }

  export type tripUpsertWithoutJoinerInput = {
    update: XOR<tripUpdateWithoutJoinerInput, tripUncheckedUpdateWithoutJoinerInput>
    create: XOR<tripCreateWithoutJoinerInput, tripUncheckedCreateWithoutJoinerInput>
    where?: tripWhereInput
  }

  export type tripUpdateToOneWithWhereWithoutJoinerInput = {
    where?: tripWhereInput
    data: XOR<tripUpdateWithoutJoinerInput, tripUncheckedUpdateWithoutJoinerInput>
  }

  export type tripUpdateWithoutJoinerInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUpdateManyWithoutTripNestedInput
    account?: accountUpdateOneWithoutTripNestedInput
  }

  export type tripUncheckedUpdateWithoutJoinerInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    IDAccount?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUncheckedUpdateManyWithoutTripNestedInput
  }

  export type accountUpsertWithoutJoinerInput = {
    update: XOR<accountUpdateWithoutJoinerInput, accountUncheckedUpdateWithoutJoinerInput>
    create: XOR<accountCreateWithoutJoinerInput, accountUncheckedCreateWithoutJoinerInput>
    where?: accountWhereInput
  }

  export type accountUpdateToOneWithWhereWithoutJoinerInput = {
    where?: accountWhereInput
    data: XOR<accountUpdateWithoutJoinerInput, accountUncheckedUpdateWithoutJoinerInput>
  }

  export type accountUpdateWithoutJoinerInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trip?: tripUpdateManyWithoutAccountNestedInput
  }

  export type accountUncheckedUpdateWithoutJoinerInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    trip?: tripUncheckedUpdateManyWithoutAccountNestedInput
  }

  export type checkpointCreateWithoutTripInput = {
    IDCheckpoint: string
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
  }

  export type checkpointUncheckedCreateWithoutTripInput = {
    IDCheckpoint: string
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
  }

  export type checkpointCreateOrConnectWithoutTripInput = {
    where: checkpointWhereUniqueInput
    create: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput>
  }

  export type checkpointCreateManyTripInputEnvelope = {
    data: checkpointCreateManyTripInput | checkpointCreateManyTripInput[]
    skipDuplicates?: boolean
  }

  export type joinerCreateWithoutTripInput = {
    type?: string | null
    status?: string | null
    account: accountCreateNestedOneWithoutJoinerInput
  }

  export type joinerUncheckedCreateWithoutTripInput = {
    IDAccount: string
    type?: string | null
    status?: string | null
  }

  export type joinerCreateOrConnectWithoutTripInput = {
    where: joinerWhereUniqueInput
    create: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput>
  }

  export type joinerCreateManyTripInputEnvelope = {
    data: joinerCreateManyTripInput | joinerCreateManyTripInput[]
    skipDuplicates?: boolean
  }

  export type accountCreateWithoutTripInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    joiner?: joinerCreateNestedManyWithoutAccountInput
  }

  export type accountUncheckedCreateWithoutTripInput = {
    IDAccount: string
    IDGoogle?: string | null
    Email?: string | null
    Org?: boolean | null
    imgURL?: string | null
    name?: string | null
    joiner?: joinerUncheckedCreateNestedManyWithoutAccountInput
  }

  export type accountCreateOrConnectWithoutTripInput = {
    where: accountWhereUniqueInput
    create: XOR<accountCreateWithoutTripInput, accountUncheckedCreateWithoutTripInput>
  }

  export type checkpointUpsertWithWhereUniqueWithoutTripInput = {
    where: checkpointWhereUniqueInput
    update: XOR<checkpointUpdateWithoutTripInput, checkpointUncheckedUpdateWithoutTripInput>
    create: XOR<checkpointCreateWithoutTripInput, checkpointUncheckedCreateWithoutTripInput>
  }

  export type checkpointUpdateWithWhereUniqueWithoutTripInput = {
    where: checkpointWhereUniqueInput
    data: XOR<checkpointUpdateWithoutTripInput, checkpointUncheckedUpdateWithoutTripInput>
  }

  export type checkpointUpdateManyWithWhereWithoutTripInput = {
    where: checkpointScalarWhereInput
    data: XOR<checkpointUpdateManyMutationInput, checkpointUncheckedUpdateManyWithoutTripInput>
  }

  export type checkpointScalarWhereInput = {
    AND?: checkpointScalarWhereInput | checkpointScalarWhereInput[]
    OR?: checkpointScalarWhereInput[]
    NOT?: checkpointScalarWhereInput | checkpointScalarWhereInput[]
    IDCheckpoint?: StringFilter<"checkpoint"> | string
    IDTrip?: StringNullableFilter<"checkpoint"> | string | null
    OrderC?: IntNullableFilter<"checkpoint"> | number | null
    createTime?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    time?: DateTimeNullableFilter<"checkpoint"> | Date | string | null
    locationName?: StringNullableFilter<"checkpoint"> | string | null
    detail?: StringNullableFilter<"checkpoint"> | string | null
    type?: StringNullableFilter<"checkpoint"> | string | null
  }

  export type joinerUpsertWithWhereUniqueWithoutTripInput = {
    where: joinerWhereUniqueInput
    update: XOR<joinerUpdateWithoutTripInput, joinerUncheckedUpdateWithoutTripInput>
    create: XOR<joinerCreateWithoutTripInput, joinerUncheckedCreateWithoutTripInput>
  }

  export type joinerUpdateWithWhereUniqueWithoutTripInput = {
    where: joinerWhereUniqueInput
    data: XOR<joinerUpdateWithoutTripInput, joinerUncheckedUpdateWithoutTripInput>
  }

  export type joinerUpdateManyWithWhereWithoutTripInput = {
    where: joinerScalarWhereInput
    data: XOR<joinerUpdateManyMutationInput, joinerUncheckedUpdateManyWithoutTripInput>
  }

  export type accountUpsertWithoutTripInput = {
    update: XOR<accountUpdateWithoutTripInput, accountUncheckedUpdateWithoutTripInput>
    create: XOR<accountCreateWithoutTripInput, accountUncheckedCreateWithoutTripInput>
    where?: accountWhereInput
  }

  export type accountUpdateToOneWithWhereWithoutTripInput = {
    where?: accountWhereInput
    data: XOR<accountUpdateWithoutTripInput, accountUncheckedUpdateWithoutTripInput>
  }

  export type accountUpdateWithoutTripInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    joiner?: joinerUpdateManyWithoutAccountNestedInput
  }

  export type accountUncheckedUpdateWithoutTripInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    IDGoogle?: NullableStringFieldUpdateOperationsInput | string | null
    Email?: NullableStringFieldUpdateOperationsInput | string | null
    Org?: NullableBoolFieldUpdateOperationsInput | boolean | null
    imgURL?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    joiner?: joinerUncheckedUpdateManyWithoutAccountNestedInput
  }

  export type joinerCreateManyAccountInput = {
    IDTrip: string
    type?: string | null
    status?: string | null
  }

  export type tripCreateManyAccountInput = {
    IDTrip: string
    IDOriginTrip?: string | null
    TripName?: string | null
    Detail?: string | null
    Preparation?: string | null
    Booking?: string | null
    createDate?: Date | string | null
    lastEdit?: Date | string | null
    private?: boolean | null
    maxJoiner?: number | null
    started?: boolean | null
    count?: number | null
  }

  export type joinerUpdateWithoutAccountInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    trip?: tripUpdateOneRequiredWithoutJoinerNestedInput
  }

  export type joinerUncheckedUpdateWithoutAccountInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerUncheckedUpdateManyWithoutAccountInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type tripUpdateWithoutAccountInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUpdateManyWithoutTripNestedInput
    joiner?: joinerUpdateManyWithoutTripNestedInput
  }

  export type tripUncheckedUpdateWithoutAccountInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
    checkpoint?: checkpointUncheckedUpdateManyWithoutTripNestedInput
    joiner?: joinerUncheckedUpdateManyWithoutTripNestedInput
  }

  export type tripUncheckedUpdateManyWithoutAccountInput = {
    IDTrip?: StringFieldUpdateOperationsInput | string
    IDOriginTrip?: NullableStringFieldUpdateOperationsInput | string | null
    TripName?: NullableStringFieldUpdateOperationsInput | string | null
    Detail?: NullableStringFieldUpdateOperationsInput | string | null
    Preparation?: NullableStringFieldUpdateOperationsInput | string | null
    Booking?: NullableStringFieldUpdateOperationsInput | string | null
    createDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastEdit?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    private?: NullableBoolFieldUpdateOperationsInput | boolean | null
    maxJoiner?: NullableIntFieldUpdateOperationsInput | number | null
    started?: NullableBoolFieldUpdateOperationsInput | boolean | null
    count?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type checkpointCreateManyTripInput = {
    IDCheckpoint: string
    OrderC?: number | null
    createTime?: Date | string | null
    time?: Date | string | null
    locationName?: string | null
    detail?: string | null
    type?: string | null
  }

  export type joinerCreateManyTripInput = {
    IDAccount: string
    type?: string | null
    status?: string | null
  }

  export type checkpointUpdateWithoutTripInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type checkpointUncheckedUpdateWithoutTripInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type checkpointUncheckedUpdateManyWithoutTripInput = {
    IDCheckpoint?: StringFieldUpdateOperationsInput | string
    OrderC?: NullableIntFieldUpdateOperationsInput | number | null
    createTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    time?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    locationName?: NullableStringFieldUpdateOperationsInput | string | null
    detail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerUpdateWithoutTripInput = {
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
    account?: accountUpdateOneRequiredWithoutJoinerNestedInput
  }

  export type joinerUncheckedUpdateWithoutTripInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type joinerUncheckedUpdateManyWithoutTripInput = {
    IDAccount?: StringFieldUpdateOperationsInput | string
    type?: NullableStringFieldUpdateOperationsInput | string | null
    status?: NullableStringFieldUpdateOperationsInput | string | null
  }



  /**
   * Aliases for legacy arg types
   */
    /**
     * @deprecated Use AccountCountOutputTypeDefaultArgs instead
     */
    export type AccountCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = AccountCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use TripCountOutputTypeDefaultArgs instead
     */
    export type TripCountOutputTypeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = TripCountOutputTypeDefaultArgs<ExtArgs>
    /**
     * @deprecated Use accountDefaultArgs instead
     */
    export type accountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = accountDefaultArgs<ExtArgs>
    /**
     * @deprecated Use checkpointDefaultArgs instead
     */
    export type checkpointArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = checkpointDefaultArgs<ExtArgs>
    /**
     * @deprecated Use joinerDefaultArgs instead
     */
    export type joinerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = joinerDefaultArgs<ExtArgs>
    /**
     * @deprecated Use tripDefaultArgs instead
     */
    export type tripArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = tripDefaultArgs<ExtArgs>

  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}