// import { PrismaClient as MySQLClient } from '';  // For MySQL
import { PrismaClient as MySQLClient } from '@prismaMysql';

const prismaMySQL = new MySQLClient();  // MySQL Client initialization

export const testConnectionsSQL = async () => {
    try {
        const result = await prismaMySQL.checkpoint.findMany()
        console.log(result)
        return result
    } catch (error) {
        return null
    }
}