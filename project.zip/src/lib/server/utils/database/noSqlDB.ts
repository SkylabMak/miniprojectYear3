import { PrismaClient as MongoClient } from '@prismaMongo';

const prismaMongo = new MongoClient();  // MySQL Client initialization

export const testConnectionsNoSQL = async () => {
    try {
        const result = await prismaMongo.checkpointNSQL.findMany()
        console.log(result)
        return result
    } catch (error) {
        return null
    }
}